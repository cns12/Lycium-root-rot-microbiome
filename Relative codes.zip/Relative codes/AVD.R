# 加载必要的包
library(ggpubr)
library(dplyr)
library(tidyr)
library(pheatmap)

# 1. 数据读取和预处理 --------------------------------------------------------

# 读取OTU丰度表
otu_raw <- read.delim('AVD.txt', row.names = 1, sep = '\t', check.names = FALSE)

# 读取分组信息
group <- read.delim('group.txt', sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)

# 2. 数据标准化 ------------------------------------------------------------

# 方法1：相对丰度标准化（转换为百分比）
otu_rel <- apply(otu_raw, 2, function(x) x/sum(x)) * 100

# 方法2：CSS标准化（更适合微生物组数据）
# 需先安装metagenomeSeq包
# if (!requireNamespace("metagenomeSeq", quietly = TRUE)) install.packages("metagenomeSeq")
# library(metagenomeSeq)
# otu_mr <- newMRexperiment(t(otu_raw))
# otu_css <- cumNorm(otu_mr, p = cumNormStatFast(otu_mr))
# otu_norm <- t(MRcounts(otu_css, norm = TRUE, log = FALSE))

# 这里我们使用相对丰度标准化进行演示
otu_norm <- otu_rel

# 3. 数据质量检查 ---------------------------------------------------------

# 检查标准化后的数据分布
summary(colSums(otu_norm))  # 应该都是100（百分比）

# 绘制热图查看整体模式
pheatmap(log10(otu_norm + 1), 
         cluster_cols = FALSE,
         main = "OTU Abundance Heatmap (log10)")

# 4. 计算AVD（群落变异度）------------------------------------------------

# 改进的AVD计算函数，处理标准化后的数据
calculate_avd <- function(otu_matrix) {
  # 计算每个OTU的变异度
  ai <- t(apply(otu_matrix, 1, function(x) {
    sd_val <- sd(x, na.rm = TRUE)
    if(is.na(sd_val) || sd_val == 0) {
      return(rep(0, length(x)))
    } else {
      return(abs(x - mean(x, na.rm = TRUE)) / sd_val)
    }
  }))
  colnames(ai) <- colnames(otu_matrix)
  
  # 计算每个样本的AVD值
  avd <- colSums(ai, na.rm = TRUE) / nrow(otu_matrix)
  return(avd)
}

# 计算AVD
avd_results <- calculate_avd(otu_norm)

# 5. 结果整合与分析 ------------------------------------------------------

# 合并AVD结果到分组数据
group$AVD <- avd_results[group$SampleID]

# 添加样本顺序信息（区分前三个样本）
group <- group %>%
  mutate(SampleOrder = gsub(".*-(\\d+)$", "\\1", SampleID) %>% as.numeric(),
         SampleSet = ifelse(SampleOrder <= 3, "Early", "Late"))

# 统计各组AVD的均值±标准差
group_stats <- group %>%
  group_by(Group) %>%
  summarise(
    Mean_AVD = mean(AVD, na.rm = TRUE),
    SD_AVD = sd(AVD, na.rm = TRUE),
    SE_AVD = sd(AVD, na.rm = TRUE)/sqrt(n()),
    .groups = 'drop'
  )

# 6. 可视化分析 ----------------------------------------------------------

# 主箱线图：按组显示AVD分布
p1 <- ggboxplot(group, x = 'Group', y = 'AVD', fill = 'Group', 
                color = 'gray30', width = 0.6, size = 1) +
  scale_fill_manual(values = c('#E7B800', '#00AFBB', '#FC4E07', '#4DBBD5', '#3C5488')) +
  labs(x = '', y = 'Average Variation Degree (AVD)', 
       title = "Microbial Community Stability by Group") +
  theme_bw() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1),
        legend.position = "none")

# 按样本集(Early/Late)分组比较
p2 <- ggboxplot(group, x = 'Group', y = 'AVD', fill = 'SampleSet', 
                color = 'gray30', width = 0.6, size = 1) +
  scale_fill_manual(values = c('#E7B800', '#00AFBB')) +
  labs(x = '', y = 'Average Variation Degree (AVD)', 
       title = "AVD Comparison: Early vs Late Samples",
       fill = "Sample Set") +
  theme_bw() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

# 7. 结果导出 -----------------------------------------------------------

# 导出计算结果
write.csv(group, "AVD_results_with_normalization.csv", row.names = FALSE)
write.csv(group_stats, "AVD_group_statistics_with_normalization.csv", row.names = FALSE)

# 保存图形
ggsave("AVD_by_group.pdf", p1, width = 8, height = 6)
ggsave("AVD_early_vs_late.pdf", p2, width = 8, height = 6)
ggsave("AVD_by_group.png", p1, width = 8, height = 6, dpi = 300)
ggsave("AVD_early_vs_late.png", p2, width = 8, height = 6, dpi = 300)

# 8. 结果显示 -----------------------------------------------------------

# 打印关键结果
print(head(group))
print(group_stats)

# 显示图形
print(p1)
print(p2)