library(ggplot2)
library(dplyr)
library(tidyr)

# 读取数据
data <- read.table("菌株互作OD比值.txt", header = TRUE, sep = "\t", stringsAsFactors = FALSE)

# 查看数据基本信息
cat("数据行数:", nrow(data), "\n")
cat("唯一源菌株数:", length(unique(data$Source)), "\n")
cat("唯一目标菌株数:", length(unique(data$Target)), "\n")

# 创建OD ratio的分类变量
data <- data %>%
  mutate(
    OD_category = case_when(
      OD.ratio > 1 ~ "大于1",
      OD.ratio < 1 ~ "小于1",
      OD.ratio == 1 ~ "等于1",
      TRUE ~ NA_character_
    ),
    OD_category = factor(OD_category, levels = c("大于1", "等于1", "小于1"))
  )

# 统计各分类的数量
cat("\nOD比值分类统计:\n")
summary_stats <- data %>%
  group_by(OD_category) %>%
  summarise(
    数量 = n(),
    百分比 = round(n() / nrow(data) * 100, 2),
    平均值 = round(mean(OD.ratio, na.rm = TRUE), 3),
    最小值 = round(min(OD.ratio, na.rm = TRUE), 3),
    最大值 = round(max(OD.ratio, na.rm = TRUE), 3)
  )
print(summary_stats)

# 方法1：调整气泡大小范围 - 更小的气泡
p1 <- ggplot(data, aes(x = Target, y = Source, size = OD.ratio, color = OD_category)) +
  geom_point(alpha = 0.7) +
  scale_size_continuous(
    name = "OD比值",
    range = c(0.5, 4),  # 减小气泡大小范围
    breaks = c(0.5, 1, 3, 6, 9, 12)  # 设置图例中的大小断点
  ) +
  scale_color_manual(
    name = "OD比值类别",
    values = c("大于1" = "#E41A1C",  # 红色
               "等于1" = "#4DAF4A",   # 绿色
               "小于1" = "#377EB8")   # 蓝色
  ) +
  theme_minimal() +
  theme(
    axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1, size = 6),
    axis.text.y = element_text(size = 6),
    axis.title = element_text(size = 10, face = "bold"),
    legend.title = element_text(size = 9, face = "bold"),
    legend.text = element_text(size = 8),
    panel.grid.major = element_line(color = "grey90", size = 0.1),
    panel.grid.minor = element_blank(),
    plot.title = element_text(size = 12, face = "bold", hjust = 0.5)
  ) +
  labs(
    title = "菌株互作OD比值矩阵气泡图",
    x = "目标菌株 (Target)",
    y = "源菌株 (Source)"
  ) +
  guides(
    color = guide_legend(override.aes = list(size = 3)),
    size = guide_legend(nrow = 2, byrow = TRUE)
  )

# 显示第一个版本
print(p1)
ggsave("菌株互作OD比值气泡图_版本1.png", p1, width = 16, height = 14, dpi = 300)

# 方法2：使用对数缩放气泡大小，避免极端值影响
p2 <- ggplot(data, aes(x = Target, y = Source, size = log10(OD.ratio + 0.1), color = OD_category)) +
  geom_point(alpha = 0.7) +
  scale_size_continuous(
    name = "OD比值(对数尺度)",
    range = c(0.5, 5),
    breaks = log10(c(0.1, 0.5, 1, 3, 6, 9, 12) + 0.1),
    labels = c("0.1", "0.5", "1", "3", "6", "9", "12")
  ) +
  scale_color_manual(
    name = "OD比值类别",
    values = c("大于1" = "#E41A1C",
               "等于1" = "#4DAF4A",
               "小于1" = "#377EB8")
  ) +
  theme_minimal() +
  theme(
    axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1, size = 6),
    axis.text.y = element_text(size = 6),
    axis.title = element_text(size = 10, face = "bold"),
    legend.title = element_text(size = 9, face = "bold"),
    legend.text = element_text(size = 8),
    panel.grid.major = element_line(color = "grey90", size = 0.1),
    panel.grid.minor = element_blank(),
    plot.title = element_text(size = 12, face = "bold", hjust = 0.5)
  ) +
  labs(
    title = "菌株互作OD比值矩阵气泡图(对数尺度)",
    x = "目标菌株 (Target)",
    y = "源菌株 (Source)"
  ) +
  guides(
    color = guide_legend(override.aes = list(size = 3))
  )

# 显示第二个版本
print(p2)
ggsave("菌株互作OD比值气泡图_版本2_对数尺度.png", p2, width = 16, height = 14, dpi = 300)

# 方法3：使用固定的气泡大小，仅通过颜色区分
p3 <- ggplot(data, aes(x = Target, y = Source, color = OD_category)) +
  geom_point(size = 2, alpha = 0.7) +
  scale_color_manual(
    name = "OD比值类别",
    values = c("大于1" = "#E41A1C",
               "等于1" = "#4DAF4A",
               "小于1" = "#377EB8")
  ) +
  theme_minimal() +
  theme(
    axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1, size = 6),
    axis.text.y = element_text(size = 6),
    axis.title = element_text(size = 10, face = "bold"),
    legend.title = element_text(size = 9, face = "bold"),
    legend.text = element_text(size = 8),
    panel.grid.major = element_line(color = "grey90", size = 0.1),
    panel.grid.minor = element_blank(),
    plot.title = element_text(size = 12, face = "bold", hjust = 0.5)
  ) +
  labs(
    title = "菌株互作OD比值矩阵图",
    subtitle = "颜色表示OD比值类别",
    x = "目标菌株 (Target)",
    y = "源菌株 (Source)"
  )

# 显示第三个版本
print(p3)
ggsave("菌株互作OD比值矩阵图_固定大小.png", p3, width = 16, height = 14, dpi = 300)

# 方法4：按类别分开绘图，更加清晰
# 创建三个分开的图，每个类别一个
data_split <- split(data, data$OD_category)

for (category in names(data_split)) {
  p <- ggplot(data_split[[category]], aes(x = Target, y = Source, size = OD.ratio, color = OD.ratio)) +
    geom_point(alpha = 0.7) +
    scale_size_continuous(
      name = "OD比值",
      range = c(1, 4)
    ) +
    scale_color_gradient(
      name = "OD比值",
      low = if(category == "小于1") "#377EB8" else "#E41A1C",
      high = if(category == "小于1") "#B3CDE3" else "#FBB4AE"
    ) +
    theme_minimal() +
    theme(
      axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1, size = 6),
      axis.text.y = element_text(size = 6),
      axis.title = element_text(size = 10, face = "bold"),
      legend.title = element_text(size = 9, face = "bold"),
      legend.text = element_text(size = 8),
      panel.grid.major = element_line(color = "grey90", size = 0.1),
      panel.grid.minor = element_blank(),
      plot.title = element_text(size = 12, face = "bold", hjust = 0.5)
    ) +
    labs(
      title = paste("菌株互作OD比值矩阵图 -", category),
      x = "目标菌株 (Target)",
      y = "源菌株 (Source)"
    )
  
  print(p)
  ggsave(paste0("菌株互作OD比值矩阵图_", category, ".png"), p, width = 16, height = 14, dpi = 300)
}

# 方法5：只显示OD比值不等于1的数据，减少数据点
data_filtered <- data %>% filter(OD.ratio != 1)

p5 <- ggplot(data_filtered, aes(x = Target, y = Source, size = OD.ratio, color = OD_category)) +
  geom_point(alpha = 0.7) +
  scale_size_continuous(
    name = "OD比值",
    range = c(1, 5),
    breaks = c(0.1, 0.5, 1, 3, 6, 9, 12)
  ) +
  scale_color_manual(
    name = "OD比值类别",
    values = c("大于1" = "#E41A1C",
               "小于1" = "#377EB8")
  ) +
  theme_minimal() +
  theme(
    axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1, size = 6),
    axis.text.y = element_text(size = 6),
    axis.title = element_text(size = 10, face = "bold"),
    legend.title = element_text(size = 9, face = "bold"),
    legend.text = element_text(size = 8),
    panel.grid.major = element_line(color = "grey90", size = 0.1),
    panel.grid.minor = element_blank(),
    plot.title = element_text(size = 12, face = "bold", hjust = 0.5)
  ) +
  labs(
    title = "菌株互作OD比值矩阵气泡图(OD≠1)",
    subtitle = "只显示OD比值不等于1的互作",
    x = "目标菌株 (Target)",
    y = "源菌株 (Source)"
  ) +
  guides(
    color = guide_legend(override.aes = list(size = 3))
  )

# 显示第五个版本
print(p5)
ggsave("菌株互作OD比值气泡图_OD不等于1.png", p5, width = 16, height = 14, dpi = 300)

# 创建汇总报告
cat("\n=== 菌株互作分析汇总 ===\n")
cat("总互作数量:", nrow(data), "\n")

# 统计每个菌株作为源菌株时的效应
source_effects <- data %>%
  group_by(Source) %>%
  summarise(
    平均OD比值 = round(mean(OD.ratio), 3),
    促进次数 = sum(OD.ratio > 1),
    抑制次数 = sum(OD.ratio < 1),
    中性次数 = sum(OD.ratio == 1)
  ) %>%
  arrange(desc(平均OD比值))

cat("\n促进效应最强的源菌株(平均OD比值最高):\n")
print(head(source_effects, 5))

cat("\n抑制效应最强的源菌株(平均OD比值最低):\n")
print(tail(source_effects, 5))

# 统计每个菌株作为目标菌株时的效应
target_effects <- data %>%
  group_by(Target) %>%
  summarise(
    平均OD比值 = round(mean(OD.ratio), 3),
    被促进次数 = sum(OD.ratio > 1),
    被抑制次数 = sum(OD.ratio < 1),
    中性次数 = sum(OD.ratio == 1)
  ) %>%
  arrange(desc(平均OD比值))

cat("\n最易被促进的目标菌株(平均OD比值最高):\n")
print(head(target_effects, 5))

cat("\n最易被抑制的目标菌株(平均OD比值最低):\n")
print(tail(target_effects, 5))

# 保存汇总数据到CSV文件
write.csv(summary_stats, "OD比值分类统计.csv", row.names = FALSE)
write.csv(source_effects, "源菌株效应统计.csv", row.names = FALSE)
write.csv(target_effects, "目标菌株效应统计.csv", row.names = FALSE)

cat("\n分析完成! 已生成5种不同版本的可视化图形和统计报告。\n")

