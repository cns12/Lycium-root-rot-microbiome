2微生物群落的beta多样性相似性或距离测度的计算
##vegan 包 vegdist() 计算群落相似性/距离，详情 ?vegdist
#以下相似度（S）和距离测度（D）的转换公式，均使用 S = 1-D
library(vegan)

#读入物种数据
otu <- read.delim('final-table.txt', row.names = 1, sep = '\t')
otu <- t(otu)

#jaccard 相异度
jacc_dis <- vegdist(otu, method = 'jaccard', binary = TRUE)
#jaccard 相似度
jacc_sim <- 1 - jacc_dis

#欧几里得距离
eucl_dis <- vegdist(otu, method = 'euclidean')
#这种距离转换为相似性时，需要首先作个标准化，例如
eucl_dis_norm <- eucl_dis/max(eucl_dis)
eucl_sim <- 1 - eucl_dis_norm

#弦距离
otu_chord <- decostand(otu, method = 'normalize')
chord_dis <- vegdist(otu_chord, method = 'euclidean')

#Hellinger 距离
otu_hell <- decostand(otu, method = 'hellinger')
hell_dis <- vegdist(otu_hell, method = 'euclidean')

#卡方距离
#先做卡方标准化，再计算欧几里得距离，即可得
otu_chi <- decostand(otu, method = 'chi.square')
otu_chi_dis <- vegdist(otu_chi, 'euclidean')

#Bray-curtis 距离
bray_dis <- vegdist(otu, method = 'bray')
#Bray-curtis 相似度
bray_sim <- 1 - bray_dis

#更多示例不再展示了
#以上结果均为 dis 类型，若要输出在本地，需要首先转化为 matrix 类型
#以 Bray-curtis 距离为例输出距离测度矩阵
bray <- as.matrix(bray_dis)
write.table(bray, 'bray-curtis_distance.txt', col.names = NA, sep = '\t', quote = FALSE)

#距离矩阵热图，红色改为样品总数除以2
heatmap(bray, scale = 'none', RowSideColors = rep(c('red', 'blue'), each = 18), ColSideColors = rep(c('red', 'blue'), each = 18))

