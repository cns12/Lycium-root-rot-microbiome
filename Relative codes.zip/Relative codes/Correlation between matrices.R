# 加载必要的包
library(ggplot2)

# 读取两个矩阵
matrix1 <- read.csv("matrix1.csv", row.names = 1, check.names = FALSE)
matrix1 <- as.matrix(matrix1)

matrix2 <- read.csv("matrix2.csv", row.names = 1, check.names = FALSE)
matrix2 <- as.matrix(matrix2)

# 检查矩阵维度
dim(matrix1)
dim(matrix2)

# 将矩阵转换为向量
vector1 <- as.vector(matrix1)
vector2 <- as.vector(matrix2)

# 计算相关性
cor_test <- cor.test(vector1, vector2, method = "pearson")
r_value <- cor_test$estimate
p_value <- cor_test$p.value
r_squared <- r_value^2

# 绘制散点图
ggplot(plot_data, aes(x = Matrix1, y = Matrix2)) +
  geom_point(alpha = 0.6, color = "blue") +  # 散点
  geom_smooth(method = "lm", color = "red", se = FALSE) +  # 线性回归线
  annotate("text", x = min(plot_data$Matrix1), y = max(plot_data$Matrix2), 
           label = paste("R² =", round(r_squared, 3), "\np =", round(p_value, 3)), 
           hjust = 0, vjust = 1, size = 5, color = "black", fontface = "bold") +  # 标注 R 方和 p 值
  labs(title = "Correlation between Matrix1 and Matrix2",
       x = "Matrix1 Values",
       y = "Matrix2 Values") +
  theme_minimal()

# 保存散点图
ggsave("correlation_plot.png", width = 8, height = 6)


