# 加载必要的包
library(dplyr)
library(tidyr)
library(stringr)
library(openxlsx)

# 读取数据
data <- read.delim("SC-P-F VS SC-P.txt", header = TRUE, stringsAsFactors = FALSE)

# 创建更详细的大分类映射函数
create_broad_category <- function(specific_class) {
  if (is.na(specific_class) || specific_class == "_") {
    return("Unclassified")
  }
  
  specific_class <- tolower(specific_class)
  
  # 定义大分类映射
  case_when(
    # Terpenoids (萜类)
    str_detect(specific_class, "terpen") ~ "Terpenoids",
    str_detect(specific_class, "diterpen") ~ "Terpenoids",
    str_detect(specific_class, "triterpen") ~ "Terpenoids",
    str_detect(specific_class, "sesquiterpen") ~ "Terpenoids",
    str_detect(specific_class, "monoterpen") ~ "Terpenoids",
    str_detect(specific_class, "sesterterpen") ~ "Terpenoids",
    
    # Steroids (类固醇)
    str_detect(specific_class, "steroid") ~ "Steroids",
    str_detect(specific_class, "pregnane") ~ "Steroids",
    str_detect(specific_class, "androstane") ~ "Steroids",
    str_detect(specific_class, "estrane") ~ "Steroids",
    str_detect(specific_class, "cholestane") ~ "Steroids",
    str_detect(specific_class, "ergostane") ~ "Steroids",
    str_detect(specific_class, "hydroxysteroid") ~ "Steroids",
    
    # Carbohydrates and Glycosides (糖类和糖苷)
    str_detect(specific_class, "carbohydrate") ~ "Carbohydrates_and_Glycosides",
    str_detect(specific_class, "glycoside") ~ "Carbohydrates_and_Glycosides",
    str_detect(specific_class, "glucoside") ~ "Carbohydrates_and_Glycosides",
    str_detect(specific_class, "sugar") ~ "Carbohydrates_and_Glycosides",
    
    # Amino acids and Peptides (氨基酸和肽)
    str_detect(specific_class, "amino acid") ~ "Amino_acids_and_Peptides",
    str_detect(specific_class, "peptide") ~ "Amino_acids_and_Peptides",
    
    # Fatty acids and Lipids (脂肪酸和脂质)
    str_detect(specific_class, "fatty") ~ "Fatty_acids_and_Lipids",
    str_detect(specific_class, "lipid") ~ "Fatty_acids_and_Lipids",
    str_detect(specific_class, "glycero") ~ "Fatty_acids_and_Lipids",
    str_detect(specific_class, "sphinganine") ~ "Fatty_acids_and_Lipids",
    str_detect(specific_class, "carnitine") ~ "Fatty_acids_and_Lipids",
    str_detect(specific_class, "lineolic") ~ "Fatty_acids_and_Lipids",
    
    # Flavonoids (黄酮类)
    str_detect(specific_class, "flavon") ~ "Flavonoids",
    str_detect(specific_class, "isoflav") ~ "Flavonoids",
    str_detect(specific_class, "chalcone") ~ "Flavonoids",
    str_detect(specific_class, "flavan") ~ "Flavonoids",
    str_detect(specific_class, "flavone") ~ "Flavonoids",
    
    # Alkaloids (生物碱)
    str_detect(specific_class, "alkaloid") ~ "Alkaloids",
    str_detect(specific_class, "purine") ~ "Alkaloids",
    str_detect(specific_class, "pyrimidine") ~ "Alkaloids",
    str_detect(specific_class, "indole") ~ "Alkaloids",
    str_detect(specific_class, "quinoline") ~ "Alkaloids",
    str_detect(specific_class, "pyrrol") ~ "Alkaloids",
    str_detect(specific_class, "piperidine") ~ "Alkaloids",
    
    # Phenolic compounds (酚类化合物)
    str_detect(specific_class, "phenol") ~ "Phenolic_compounds",
    str_detect(specific_class, "coumarin") ~ "Phenolic_compounds",
    str_detect(specific_class, "caffeoyl") ~ "Phenolic_compounds",
    str_detect(specific_class, "hydroxycinnamic") ~ "Phenolic_compounds",
    str_detect(specific_class, "hydroxybenzoic") ~ "Phenolic_compounds",
    str_detect(specific_class, "methoxyphenol") ~ "Phenolic_compounds",
    str_detect(specific_class, "benzenetriol") ~ "Phenolic_compounds",
    
    # Lactones (内酯类)
    str_detect(specific_class, "lactone") ~ "Lactones",
    
    # Carboxylic acids and derivatives (羧酸及其衍生物)
    str_detect(specific_class, "carboxylic") ~ "Carboxylic_acids",
    str_detect(specific_class, "benzoic") ~ "Carboxylic_acids",
    
    # Alcohols and Polyols (醇类)
    str_detect(specific_class, "alcohol") ~ "Alcohols_and_Polyols",
    str_detect(specific_class, "polyol") ~ "Alcohols_and_Polyols",
    
    # Aldehydes and Ketones (醛酮类)
    str_detect(specific_class, "aldehyde") ~ "Aldehydes_and_Ketones",
    str_detect(specific_class, "ketone") ~ "Aldehydes_and_Ketones",
    
    # Amines and Amides (胺类和酰胺类)
    str_detect(specific_class, "amine") ~ "Amines_and_Amides",
    str_detect(specific_class, "amide") ~ "Amines_and_Amides",
    
    # Esters (酯类)
    str_detect(specific_class, "ester") ~ "Esters",
    
    # Ethers (醚类)
    str_detect(specific_class, "ether") ~ "Ethers",
    
    # Heterocyclic compounds (杂环化合物)
    str_detect(specific_class, "pyridine") ~ "Heterocyclic_compounds",
    str_detect(specific_class, "pyrazole") ~ "Heterocyclic_compounds",
    str_detect(specific_class, "imidazole") ~ "Heterocyclic_compounds",
    str_detect(specific_class, "triazine") ~ "Heterocyclic_compounds",
    str_detect(specific_class, "oxane") ~ "Heterocyclic_compounds",
    str_detect(specific_class, "thiazine") ~ "Heterocyclic_compounds",
    str_detect(specific_class, "diazepine") ~ "Heterocyclic_compounds",
    
    # Aromatic compounds (芳香族化合物)
    str_detect(specific_class, "benzene") ~ "Aromatic_compounds",
    str_detect(specific_class, "phenyl") ~ "Aromatic_compounds",
    str_detect(specific_class, "naphth") ~ "Aromatic_compounds",
    str_detect(specific_class, "anthracene") ~ "Aromatic_compounds",
    str_detect(specific_class, "phenanthrene") ~ "Aromatic_compounds",
    
    # Eicosanoids (类二十烷酸)
    str_detect(specific_class, "eicosanoid") ~ "Eicosanoids",
    str_detect(specific_class, "prostaglandin") ~ "Eicosanoids",
    
    # Quinones (醌类)
    str_detect(specific_class, "quinone") ~ "Quinones",
    
    # 默认分类 - 现在更少物质会进入这个分类
    TRUE ~ "Other_organic_compounds"
  )
}

# 应用大分类映射
data$broad_category <- sapply(data$class, create_broad_category)

# 统计大分类
broad_category_summary <- data %>%
  group_by(broad_category, direction) %>%
  summarise(count = n(), .groups = "drop") %>%
  arrange(broad_category, direction)

# 创建宽格式表格
broad_wide_summary <- broad_category_summary %>%
  pivot_wider(names_from = direction, values_from = count, values_fill = 0) %>%
  mutate(
    total = down + up,
    down_percent = round(down / total * 100, 1),
    up_percent = round(up / total * 100, 1)
  ) %>%
  arrange(desc(total))

# 查看结果
print("Broad category summary:")
print(broad_wide_summary)

# 保存为Excel文件
write.xlsx(broad_wide_summary, "broad_category_summary.xlsx")

# 保存原始数据与分类
data_with_broad_category <- data
write.xlsx(data_with_broad_category, "substances_with_broad_categories.xlsx")

# 可视化
library(ggplot2)

# 创建堆叠条形图
p1 <- ggplot(broad_wide_summary, aes(x = reorder(broad_category, total), y = total)) +
  geom_bar(aes(fill = "Total"), stat = "identity", alpha = 0.6) +
  geom_bar(aes(y = down, fill = "Down"), stat = "identity") +
  geom_bar(aes(y = up, fill = "Up"), stat = "identity") +
  coord_flip() +
  labs(
    title = "Substances Distribution by Broad Category",
    x = "Broad Category",
    y = "Number of Substances",
    fill = "Type"
  ) +
  theme_minimal() +
  theme(
    axis.text.y = element_text(size = 10),
    legend.position = "bottom"
  )

print(p1)
ggsave("broad_category_distribution.png", width = 12, height = 8, dpi = 300)

# 输出统计摘要
cat("\n=== Broad Category Statistics ===\n")
cat("Total broad categories:", nrow(broad_wide_summary), "\n")
cat("Total substances:", sum(broad_wide_summary$total), "\n")
cat("Down-regulated substances:", sum(broad_wide_summary$down), "\n")
cat("Up-regulated substances:", sum(broad_wide_summary$up), "\n")
cat("Down-regulation percentage:", round(sum(broad_wide_summary$down) / sum(broad_wide_summary$total) * 100, 1), "%\n")
cat("Up-regulation percentage:", round(sum(broad_wide_summary$up) / sum(broad_wide_summary$total) * 100, 1), "%\n")

cat("\nTop 5 broad categories:\n")
print(head(broad_wide_summary, 5))

# 查看"Other_organic_compounds"中的具体分类
other_organic <- data %>%
  filter(broad_category == "Other_organic_compounds") %>%
  group_by(class) %>%
  summarise(count = n()) %>%
  arrange(desc(count))

cat("\nSpecific classes in 'Other_organic_compounds':\n")
print(other_organic)

