# 加载必要的包
library(pheatmap)

# 读取 CSV 文件
data <- read.csv("39属菌株之间进化距离.csv", row.names = 1, check.names = FALSE)

# 将数据框转换为矩阵
data_matrix <- as.matrix(data)

# 生成热图（保持原始顺序）
pheatmap(data_matrix, 
         color = colorRampPalette(c("blue", "white", "red"))(100),
         cluster_rows = FALSE,  # 禁用行聚类
         cluster_cols = FALSE,  # 禁用列聚类
         show_rownames = TRUE,  # 显示行名
         show_colnames = TRUE,  # 显示列名
         fontsize_row = 6,  # 行名字体大小
         fontsize_col = 6)  # 列名字体大小

