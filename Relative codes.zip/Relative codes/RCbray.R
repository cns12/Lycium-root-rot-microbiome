# 读取原始数据
# 加载必要的包
library(vegan)
comm.orig <- read.table(file = "枸杞细菌群落.txt", sep = "\t", header = TRUE, row.names = 1)  # 读取OTU表格数据
comm.trans <- t(comm.orig)  # 转置数据，使得每行表示一个样本，每列表示一个物种或OTU

# 设置分析方法和计算距离
method <- "bray"
if (method == "jaccard") {
  binary <- TRUE
} else {
  binary <- FALSE
}
comm <- comm.trans[, colSums(comm.trans) > 0]  # 剔除掉所有OTU均为0的列
dt.obs <- as.matrix(vegdist(comm, method = method, binary = binary))  # 计算实际群落数据的距离矩阵

# 随机化过程
dt.null.list <- list()
rand <- 500
for (i in 1:rand) {
  comm.rand <- comm
  comm.rand[] <- 0
  prob.species <- colSums(comm > 0)
  prob.abundance <- colSums(comm)
  species <- rowSums(comm > 0)
  samps <- rowSums(comm)
  for (j in 1:nrow(comm)) {
    id.species <- sample(1:ncol(comm), species[j], replace = FALSE, prob = prob.species)
    count <- sample(id.species, (samps[j] - species[j]), replace = TRUE, prob = prob.abundance[id.species])
    table <- table(count)
    comm.rand[j, as.numeric(names(table))] <- as.vector(table)
    comm.rand[j, id.species] <- comm.rand[j, id.species] + 1
  }
  dt.null.list[[i]] <- as.matrix(vegdist(comm.rand, method = method, binary = binary))
}

# 处理随机化结果并计算Raup-Crick指数
dt.null.array <- array(unlist(dt.null.list), dim = c(nrow(dt.null.list[[1]]), ncol(dt.null.list[[1]]), length(dt.null.list)))
comp <- function(x, c) {
  (x < c) + 0.5 * (x == c)
}
alpha <- matrix(rowSums(apply(dt.null.array, 3, comp, c = dt.obs)), nrow = nrow(dt.obs)) / rand
rc <- (alpha - 0.5) * 2
rownames(rc) <- rownames(dt.obs)
colnames(rc) <- colnames(dt.obs)

# 将结果写入CSV文件
write.csv(rc, paste("RaupCrick.", method, ".", rand, ".csv", sep = ""))

