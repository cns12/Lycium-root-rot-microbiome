# 加载必要的包
library(ggplot2)
library(dplyr)
library(tidyr)
library(vegan)  # 用于PERMANOVA分析

# 读取数据
pca_data <- read.delim("PCA.txt", header = TRUE, sep = "\t", stringsAsFactors = FALSE)

# 提取样本名称和PC矩阵
sample_names <- pca_data[, 1]
pc_matrix <- as.matrix(pca_data[, -1])

# 计算每个PC的方差和解释比例
pc_variance <- apply(pc_matrix, 2, var)
total_variance <- sum(pc_variance)
variance_explained <- (pc_variance / total_variance) * 100

# 创建分组信息 - 根据样本名称前缀
groups <- case_when(
  grepl("^SC-P-F-", sample_names) ~ "SC-P-F",
  grepl("^SC-P-", sample_names) ~ "SC-P", 
  grepl("^SC-F-", sample_names) ~ "SC-F",
  grepl("^P-F-", sample_names) ~ "P-F",
  grepl("^SC-", sample_names) ~ "SC",
  grepl("^P-", sample_names) ~ "P",
  grepl("^F-", sample_names) ~ "F",
  grepl("^CK-", sample_names) ~ "CK",
  TRUE ~ "Other"
)

# 创建数据框用于绘图
pc_scores <- data.frame(
  Sample = sample_names,
  PC1 = pc_matrix[, 1],
  PC2 = pc_matrix[, 2],
  Group = factor(groups)
)

# 执行PERMANOVA分析获取p值
# 使用前10个主成分进行PERMANOVA分析
if(ncol(pc_matrix) >= 10) {
  dist_matrix <- dist(pc_matrix[, 1:10])
  permanova_result <- adonis2(dist_matrix ~ groups)
  p_value <- permanova_result$`Pr(>F)`[1]
  r_squared <- permanova_result$R2[1]
} else {
  dist_matrix <- dist(pc_matrix)
  permanova_result <- adonis2(dist_matrix ~ groups)
  p_value <- permanova_result$`Pr(>F)`[1]
  r_squared <- permanova_result$R2[1]
}

# 创建带有方差解释的坐标轴标签
x_label <- paste0("PC1 (", round(variance_explained[1], 2), "%)")
y_label <- paste0("PC2 (", round(variance_explained[2], 2), "%)")

# 定义8个组别的颜色方案
group_colors <- c(
  "SC-P-F" = "#E41A1C",  # 红色
  "SC-P" = "#377EB8",    # 蓝色
  "SC-F" = "#4DAF4A",    # 绿色
  "P-F" = "#984EA3",     # 紫色
  "SC" = "#FF7F00",      # 橙色
  "P" = "#FFFF00",       # 黄色
  "F" = "#A65628",       # 棕色
  "CK" = "#F781BF"       # 粉色
)

# 定义通用主题，使图片为正方形并添加轴框
square_theme <- theme(
  aspect.ratio = 1,  # 确保图形为正方形
  panel.border = element_rect(colour = "black", fill = NA, size = 1),  # 添加黑色边框
  panel.grid.major = element_line(color = "grey90"),
  panel.grid.minor = element_blank(),
  legend.position = "right",
  plot.title = element_text(hjust = 0.5, size = 14, face = "bold"),
  plot.subtitle = element_text(hjust = 0.5, size = 11),
  legend.text = element_text(size = 10),
  legend.title = element_text(size = 12, face = "bold")
)

# 1. 绘制PC1 vs PC2，不带标签，添加置信椭圆，显示分析方法和p值
p1 <- ggplot(pc_scores, aes(x = PC1, y = PC2, color = Group, fill = Group)) +
  geom_point(size = 3, alpha = 0.8) +
  stat_ellipse(level = 0.95, type = "norm", alpha = 0.2, geom = "polygon") + # 95%置信椭圆
  labs(title = "PCA Plot - PC1 vs PC2",
       subtitle = paste0("PERMANOVA: R² = ", round(r_squared, 3), 
                         ", p = ", format.pval(p_value, digits = 2, eps = 0.001),
                         "\nTotal variance explained: ", 
                         round(variance_explained[1] + variance_explained[2], 1), "%"),
       x = x_label,
       y = y_label,
       color = "Group",
       fill = "Group") +
  theme_minimal() +
  scale_color_manual(values = group_colors) +
  scale_fill_manual(values = group_colors) +
  square_theme

print(p1)

# 2. 绘制PC1 vs PC3
if(ncol(pc_matrix) >= 3) {
  pc_scores_13 <- data.frame(
    Sample = sample_names,
    PC1 = pc_matrix[, 1],
    PC3 = pc_matrix[, 3],
    Group = factor(groups)
  )
  
  x_label_13 <- paste0("PC1 (", round(variance_explained[1], 2), "%)")
  y_label_13 <- paste0("PC3 (", round(variance_explained[3], 2), "%)")
  
  p2 <- ggplot(pc_scores_13, aes(x = PC1, y = PC3, color = Group, fill = Group)) +
    geom_point(size = 3, alpha = 0.8) +
    stat_ellipse(level = 0.95, type = "norm", alpha = 0.2, geom = "polygon") +
    labs(title = "PCA Plot - PC1 vs PC3",
         subtitle = paste0("PERMANOVA: R² = ", round(r_squared, 3), 
                           ", p = ", format.pval(p_value, digits = 2, eps = 0.001),
                           "\nTotal variance explained: ", 
                           round(variance_explained[1] + variance_explained[3], 1), "%"),
         x = x_label_13,
         y = y_label_13,
         color = "Group",
         fill = "Group") +
    theme_minimal() +
    scale_color_manual(values = group_colors) +
    scale_fill_manual(values = group_colors) +
    square_theme
  
  print(p2)
}

# 3. 绘制PC2 vs PC3
if(ncol(pc_matrix) >= 3) {
  pc_scores_23 <- data.frame(
    Sample = sample_names,
    PC2 = pc_matrix[, 2],
    PC3 = pc_matrix[, 3],
    Group = factor(groups)
  )
  
  x_label_23 <- paste0("PC2 (", round(variance_explained[2], 2), "%)")
  y_label_23 <- paste0("PC3 (", round(variance_explained[3], 2), "%)")
  
  p3 <- ggplot(pc_scores_23, aes(x = PC2, y = PC3, color = Group, fill = Group)) +
    geom_point(size = 3, alpha = 0.8) +
    stat_ellipse(level = 0.95, type = "norm", alpha = 0.2, geom = "polygon") +
    labs(title = "PCA Plot - PC2 vs PC3",
         subtitle = paste0("PERMANOVA: R² = ", round(r_squared, 3), 
                           ", p = ", format.pval(p_value, digits = 2, eps = 0.001),
                           "\nTotal variance explained: ", 
                           round(variance_explained[2] + variance_explained[3], 1), "%"),
         x = x_label_23,
         y = y_label_23,
         color = "Group",
         fill = "Group") +
    theme_minimal() +
    scale_color_manual(values = group_colors) +
    scale_fill_manual(values = group_colors) +
    square_theme
  
  print(p3)
}

# 4. 绘制方差解释条形图
variance_df <- data.frame(
  PC = factor(paste0("PC", 1:10), levels = paste0("PC", 1:10)),
  Variance = variance_explained[1:10]
)

# 为条形图创建不同的主题（不需要正方形）
bar_theme <- theme(
  panel.border = element_rect(colour = "black", fill = NA, size = 1),  # 添加黑色边框
  panel.grid.major = element_line(color = "grey90"),
  panel.grid.minor = element_blank(),
  plot.title = element_text(hjust = 0.5, size = 14, face = "bold"),
  axis.text.x = element_text(angle = 45, hjust = 1)
)

p4 <- ggplot(variance_df, aes(x = PC, y = Variance)) +
  geom_bar(stat = "identity", fill = "steelblue", alpha = 0.8) +
  geom_text(aes(label = sprintf("%.1f%%", Variance)), vjust = -0.5, size = 3) +
  labs(title = "Variance Explained by Principal Components",
       subtitle = paste0("Analysis: Principal Component Analysis (PCA)\n",
                         "Total variance captured by first 10 PCs: ", 
                         round(sum(variance_explained[1:10]), 1), "%"),
       x = "Principal Components",
       y = "Variance Explained (%)") +
  theme_minimal() +
  ylim(0, max(variance_df$Variance) * 1.1) +
  bar_theme

print(p4)

# 5. 绘制累积方差解释图
cumulative_variance <- cumsum(variance_explained)
cumulative_df <- data.frame(
  PC = factor(paste0("PC", 1:10), levels = paste0("PC", 1:10)),
  Cumulative = cumulative_variance[1:10]
)

p5 <- ggplot(cumulative_df, aes(x = PC, y = Cumulative, group = 1)) +
  geom_line(color = "red", size = 1) +
  geom_point(color = "red", size = 2) +
  geom_text(aes(label = sprintf("%.1f%%", Cumulative)), vjust = -1, size = 3) +
  labs(title = "Cumulative Variance Explained",
       subtitle = paste0("Analysis: Principal Component Analysis (PCA)\n",
                         "PERMANOVA: R² = ", round(r_squared, 3), 
                         ", p = ", format.pval(p_value, digits = 2, eps = 0.001)),
       x = "Number of Principal Components",
       y = "Cumulative Variance Explained (%)") +
  theme_minimal() +
  ylim(0, 100) +
  bar_theme

print(p5)

# 6. 绘制 scree plot
scree_data <- data.frame(
  PC = 1:length(variance_explained),
  Variance = variance_explained
)

p6 <- ggplot(scree_data[1:20, ], aes(x = PC, y = Variance)) +
  geom_line(color = "blue", size = 1) +
  geom_point(color = "blue", size = 2) +
  labs(title = "Scree Plot",
       subtitle = paste0("Analysis: Principal Component Analysis (PCA)\n",
                         "Total variance: 100% across ", length(variance_explained), " PCs"),
       x = "Principal Component",
       y = "Variance Explained (%)") +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 14, face = "bold"),
    plot.subtitle = element_text(hjust = 0.5, size = 10),
    panel.border = element_rect(colour = "black", fill = NA, size = 1)  # 添加黑色边框
  )

print(p6)

# 保存图形 - 使用正方形尺寸
ggsave("PCA_PC1_vs_PC2_8groups.png", p1, width = 8, height = 8, dpi = 300)  # 正方形
if(ncol(pc_matrix) >= 3) {
  ggsave("PCA_PC1_vs_PC3_8groups.png", p2, width = 8, height = 8, dpi = 300)  # 正方形
  ggsave("PCA_PC2_vs_PC3_8groups.png", p3, width = 8, height = 8, dpi = 300)  # 正方形
}
ggsave("Variance_Explained_8groups.png", p4, width = 10, height = 8, dpi = 300)  # 长方形
ggsave("Cumulative_Variance_8groups.png", p5, width = 10, height = 8, dpi = 300)  # 长方形
ggsave("Scree_Plot_8groups.png", p6, width = 10, height = 8, dpi = 300)  # 长方形

# 输出统计信息
cat("=== PCA分析结果 ===\n")
cat(sprintf("PC1解释方差: %.2f%%\n", variance_explained[1]))
cat(sprintf("PC2解释方差: %.2f%%\n", variance_explained[2]))
cat(sprintf("PC3解释方差: %.2f%%\n", variance_explained[3]))
cat(sprintf("PC1+PC2累计解释方差: %.2f%%\n", variance_explained[1] + variance_explained[2]))
cat(sprintf("PC1+PC2+PC3累计解释方差: %.2f%%\n", 
            variance_explained[1] + variance_explained[2] + variance_explained[3]))
cat("\nPERMANOVA分析结果:\n")
cat(sprintf("R² = %.3f, p = %s\n", r_squared, format.pval(p_value, digits = 2, eps = 0.001)))
cat("\n样本分组统计:\n")
print(table(groups))

# 保存分组信息
write.csv(data.frame(Sample = sample_names, Group = groups), 
          "sample_groups_info.csv", row.names = FALSE)

# 保存方差解释结果
variance_results <- data.frame(
  PC = paste0("PC", 1:length(variance_explained)),
  Variance_Explained = variance_explained,
  Cumulative_Variance = cumulative_variance
)
write.csv(variance_results, "PCA_variance_results_8groups.csv", row.names = FALSE)

# 保存PERMANOVA结果
permanova_results <- data.frame(
  Method = "PERMANOVA",
  R_squared = r_squared,
  P_value = p_value,
  Formula = "dist_matrix ~ groups"
)
write.csv(permanova_results, "PERMANOVA_results.csv", row.names = FALSE)

cat("\n分析完成！图形已保存到当前工作目录。\n")

