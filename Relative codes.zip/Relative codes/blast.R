# 加载必要的包
if (!require("Biostrings")) {
  if (!require("BiocManager")) install.packages("BiocManager")
  BiocManager::install("Biostrings")
}
if (!require("seqinr")) install.packages("seqinr")

library(Biostrings)
library(seqinr)

# 1. 读取序列文件
read_fasta <- function(file_path) {
  lines <- readLines(file_path)
  seq_names <- character()
  sequences <- character()
  current_seq <- ""
  
  for (line in lines) {
    if (startsWith(line, ">")) {
      # 如果已有序列，先保存
      if (nchar(current_seq) > 0) {
        sequences <- c(sequences, current_seq)
        current_seq <- ""
      }
      seq_names <- c(seq_names, sub(">", "", line))
    } else {
      current_seq <- paste0(current_seq, gsub("\\s+", "", line))
    }
  }
  
  # 添加最后一个序列
  if (nchar(current_seq) > 0) {
    sequences <- c(sequences, current_seq)
  }
  
  # 转换为DNAStringSet对象
  dna_set <- DNAStringSet(sequences)
  names(dna_set) <- seq_names
  
  return(dna_set)
}

# 读取两个文件
seq_file1 <- read_fasta("Pseudomonas 5-2.txt")
seq_file2 <- read_fasta("ASV假单胞菌.txt")

cat("文件1包含", length(seq_file1), "条序列\n")
cat("文件2包含", length(seq_file2), "条序列\n")

# 2. 进行两两比对
perform_pairwise_alignments <- function(seq_set1, seq_set2, output_file) {
  # 创建输出文件
  sink(output_file)
  
  cat("========================================\n")
  cat("两两序列比对结果\n")
  cat("文件1 vs 文件2\n")
  cat("生成时间:", Sys.time(), "\n")
  cat("========================================\n\n")
  
  total_alignments <- length(seq_set1) * length(seq_set2)
  alignment_count <- 0
  
  for (i in 1:length(seq_set1)) {
    seq1_name <- names(seq_set1)[i]
    seq1 <- seq_set1[[i]]
    
    for (j in 1:length(seq_set2)) {
      seq2_name <- names(seq_set2)[j]
      seq2 <- seq_set2[[j]]
      
      alignment_count <- alignment_count + 1
      cat(sprintf("\n[比对 %d/%d]\n", alignment_count, total_alignments))
      cat("序列1:", seq1_name, "\n")
      cat("序列2:", seq2_name, "\n")
      cat("序列1长度:", nchar(seq1), "\n")
      cat("序列2长度:", nchar(seq2), "\n")
      
      # 执行全局比对（Needleman-Wunsch算法）
      alignment <- pairwiseAlignment(seq1, seq2, 
                                     type = "global",
                                     gapOpening = 10,
                                     gapExtension = 0.5,
                                     scoreOnly = FALSE)
      
      # 提取比对结果
      aligned_seq1 <- as.character(pattern(alignment))
      aligned_seq2 <- as.character(subject(alignment))
      
      # 计算相似性统计
      match_count <- sum(strsplit(aligned_seq1, "")[[1]] == 
                           strsplit(aligned_seq2, "")[[1]])
      alignment_length <- nchar(aligned_seq1)
      similarity <- match_count / alignment_length * 100
      
      cat("比对得分:", score(alignment), "\n")
      cat("比对长度:", alignment_length, "\n")
      cat("匹配数:", match_count, "\n")
      cat("相似度:", round(similarity, 2), "%\n")
      cat("空位数:", sum(strsplit(aligned_seq1, "")[[1]] == "-") + 
            sum(strsplit(aligned_seq2, "")[[1]] == "-"), "\n")
      
      # 显示部分比对结果（太长则截取）
      cat("\n比对结果（显示前200个字符）:\n")
      
      if (alignment_length > 200) {
        display_len <- 200
        display_seq1 <- substring(aligned_seq1, 1, display_len)
        display_seq2 <- substring(aligned_seq2, 1, display_len)
        
        # 创建匹配行
        match_line <- ""
        for (k in 1:display_len) {
          if (substring(display_seq1, k, k) == substring(display_seq2, k, k)) {
            match_line <- paste0(match_line, "|")
          } else {
            match_line <- paste0(match_line, " ")
          }
        }
        
        cat("序列1:", display_seq1, "...\n")
        cat("        ", match_line, "\n")
        cat("序列2:", display_seq2, "...\n")
        cat("(完整比对共", alignment_length, "个字符)\n")
      } else {
        # 完整显示
        match_line <- ""
        for (k in 1:alignment_length) {
          if (substring(aligned_seq1, k, k) == substring(aligned_seq2, k, k)) {
            match_line <- paste0(match_line, "|")
          } else {
            match_line <- paste0(match_line, " ")
          }
        }
        
        cat("序列1:", aligned_seq1, "\n")
        cat("        ", match_line, "\n")
        cat("序列2:", aligned_seq2, "\n")
      }
      
      cat("\n", rep("-", 80), "\n", sep = "")
    }
  }
  
  sink()
  cat("比对结果已保存到:", output_file, "\n")
}

# 3. 执行比对并保存结果
output_file <- "sequence_alignments_results.txt"
perform_pairwise_alignments(seq_file1, seq_file2, output_file)

# 4. 生成相似度矩阵
generate_similarity_matrix <- function(seq_set1, seq_set2, output_csv) {
  similarity_matrix <- matrix(0, nrow = length(seq_set1), ncol = length(seq_set2))
  rownames(similarity_matrix) <- names(seq_set1)
  colnames(similarity_matrix) <- names(seq_set2)
  
  for (i in 1:length(seq_set1)) {
    seq1 <- seq_set1[[i]]
    
    for (j in 1:length(seq_set2)) {
      seq2 <- seq_set2[[j]]
      
      alignment <- pairwiseAlignment(seq1, seq2, 
                                     type = "global",
                                     gapOpening = 10,
                                     gapExtension = 0.5)
      
      aligned_seq1 <- as.character(pattern(alignment))
      aligned_seq2 <- as.character(subject(alignment))
      
      match_count <- sum(strsplit(aligned_seq1, "")[[1]] == 
                           strsplit(aligned_seq2, "")[[1]])
      alignment_length <- nchar(aligned_seq1)
      similarity <- match_count / alignment_length * 100
      
      similarity_matrix[i, j] <- round(similarity, 2)
    }
  }
  
  # 保存为CSV文件
  write.csv(similarity_matrix, output_csv)
  cat("相似度矩阵已保存到:", output_csv, "\n")
  
  return(similarity_matrix)
}

# 生成相似度矩阵
matrix_csv <- "similarity_matrix.csv"
similarity_matrix <- generate_similarity_matrix(seq_file1, seq_file2, matrix_csv)

# 5. 可视化相似度矩阵（可选）
if (!require("pheatmap")) install.packages("pheatmap")
library(pheatmap)

# 创建热图
pdf("similarity_heatmap.pdf", width = 12, height = 10)
pheatmap(similarity_matrix,
         main = "序列相似度热图",
         display_numbers = TRUE,
         number_format = "%.1f",
         fontsize_row = 8,
         fontsize_col = 8,
         cluster_rows = TRUE,
         cluster_cols = TRUE)
dev.off()
cat("相似度热图已保存到: similarity_heatmap.pdf\n")

# 6. 寻找最相似的序列对
find_top_matches <- function(similarity_matrix, top_n = 10) {
  # 将矩阵转换为数据框
  matches <- data.frame()
  
  for (i in 1:nrow(similarity_matrix)) {
    for (j in 1:ncol(similarity_matrix)) {
      matches <- rbind(matches, 
                       data.frame(Seq1 = rownames(similarity_matrix)[i],
                                  Seq2 = colnames(similarity_matrix)[j],
                                  Similarity = similarity_matrix[i, j]))
    }
  }
  
  # 按相似度排序
  top_matches <- matches[order(-matches$Similarity), ][1:top_n, ]
  
  # 保存结果
  write.csv(top_matches, "top_matches.csv", row.names = FALSE)
  cat("最相似序列对已保存到: top_matches.csv\n")
  
  return(top_matches)
}

# 找出最相似的10对序列
top_matches <- find_top_matches(similarity_matrix, top_n = 10)

# 7. 输出摘要报告
cat("\n========================================\n")
cat("分析摘要\n")
cat("========================================\n")
cat("总比对数量:", length(seq_file1) * length(seq_file2), "\n")
cat("最高相似度:", max(similarity_matrix), "%\n")
cat("最低相似度:", min(similarity_matrix), "%\n")
cat("平均相似度:", mean(similarity_matrix), "%\n")
cat("\n最相似的3对序列:\n")
print(top_matches[1:3, ])

