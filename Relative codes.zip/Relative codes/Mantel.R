#安装 linkET 包
#install.packages('devtools')
devtools::install_github('Hy4m/linkET')

library(linkET)
library(ggplot2)
library(dplyr)

#读取示例数据
micro <- read.delim('健康组微生物.txt', row.names = 1)
env <- read.delim('健康组理化.txt', row.names = 1)

#计算 Mantel 相关性
mantel <- mantel_test(spec = micro, env = env, spec_select = list(Taxonomy = 1:578, Function = 579:757), mantel_fun = 'mantel')

#根据相关系数和显著性设置标签，以便作图时定义线宽和颜色
mantel <- mutate(mantel, 
                 rd = cut(r, breaks = c(-Inf, 0.2, 0.4, Inf), labels = c('< 0.2', '0.2 - 0.4', '>= 0.4')),
                 pd = cut(p, breaks = c(-Inf, 0.01, 0.05, Inf), labels = c('< 0.01', '0.01 - 0.05', '>= 0.05'))
)

# 导出 Mantel 检验结果到 CSV 文件
write.csv(mantel, "Mantel_test_results.csv", row.names = FALSE)
cat("Mantel 检验结果已导出到 Mantel_test_results.csv\n")

# 方法1: 使用基础 R 的 cor() 函数计算相关性矩阵
env_cor_matrix <- cor(env, method = "spearman")
write.csv(env_cor_matrix, "Environmental_variables_correlation_matrix.csv")
cat("环境变量相关性矩阵已导出到 Environmental_variables_correlation_matrix.csv\n")

# 方法2: 如果需要 p 值，使用 psych 包
if (!require(psych)) {
  install.packages("psych")
  library(psych)
}
env_cor_with_p <- corr.test(env, method = "spearman")

# 导出相关系数
write.csv(env_cor_with_p$r, "Environmental_variables_correlation_coefficients.csv")
cat("环境变量相关系数已导出到 Environmental_variables_correlation_coefficients.csv\n")

# 导出 p 值
write.csv(env_cor_with_p$p, "Environmental_variables_correlation_pvalues.csv")
cat("环境变量相关性 p 值已导出到 Environmental_variables_correlation_pvalues.csv\n")

# 导出完整的相关性检验结果
env_cor_results <- data.frame(
  Variable1 = rep(colnames(env), each = ncol(env)),
  Variable2 = rep(colnames(env), times = ncol(env)),
  Correlation = as.vector(env_cor_with_p$r),
  P_value = as.vector(env_cor_with_p$p)
)
write.csv(env_cor_results, "Environmental_variables_correlation_full_results.csv", row.names = FALSE)
cat("完整的环境变量相关性结果已导出到 Environmental_variables_correlation_full_results.csv\n")

#绘制相关图（保持不变）
qcorrplot(correlate(env, method = 'spearman'), type = 'upper', diag = FALSE) +
  geom_square() +
  geom_mark(sep = '\n', size = 2.5, sig.thres = 0.05) +
  geom_couple(aes(color = pd, size = rd), data = mantel, curvature = nice_curvature()) +
  scale_fill_gradientn(colors = c('#053061', '#68A8CF', 'white', '#F7B394', '#67001F'), limits = c(-1, 1)) +
  scale_size_manual(values = c(0.5, 1, 2)) +
  scale_color_manual(values = c('#D95F02', '#1B9E77', '#E0E0E0')) +
  guides(color = guide_legend(title = "Mantel's p", order = 1),
         size = guide_legend(title = "Mantel's r", order = 2), 
         fill = guide_colorbar(title = "Spearman's r", order = 3)) +
  theme(legend.key = element_blank())

