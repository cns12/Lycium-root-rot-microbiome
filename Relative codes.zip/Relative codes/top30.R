# =============================================================================
# 7个比较组TOP30差异代谢物条形图（分别保存）
# 输入：7个差异代谢物文件（制表符分隔，包含compounds, class, logFC等列）
# 输出：
#   1. 每个组的TOP30条形图（PDF和PNG格式）
#   2. 统一分类映射表.csv - 各物质统一分类
#   3. 所有组别分类统计汇总.csv - 各组TOP30中各类别计数
# =============================================================================

# 加载必要的包
library(readr)
library(ggplot2)
library(dplyr)
library(tidyr)
library(tools)

# 定义7个组别的文件列表（确保文件名与实际一致）
group_files <- c(
  "CKF最终差异物质.txt",
  "PFP最终差异物质.txt",
  "PFvsCK最终.txt",
  "SC-FCK最终差异物质.txt",
  "SCFSC最终差异物质.txt",
  "SCPFSCP最终差异物质.txt",
  "SC-P-FCK最终差异物质.txt"
)

# 1. 创建统一的分类映射表 ------------------------------------------------
create_unified_class_mapping <- function(file_paths) {
  all_compounds <- data.frame()
  for (file in file_paths) {
    if (file.exists(file)) {
      data <- read.delim(file, header = TRUE, stringsAsFactors = FALSE)
      compounds_data <- data %>% select(compounds, class) %>% distinct()
      all_compounds <- bind_rows(all_compounds, compounds_data)
    }
  }
  # 对每个物质，取出现频率最高的分类作为统一分类
  class_mapping <- all_compounds %>%
    group_by(compounds) %>%
    count(class) %>%
    arrange(desc(n)) %>%
    slice(1) %>%
    ungroup() %>%
    select(compounds, unified_class = class)
  return(class_mapping)
}

# 2. 创建颜色映射 ---------------------------------------------------------
create_color_mapping <- function(class_mapping) {
  unique_classes <- unique(class_mapping$unified_class)
  # 柔和的配色方案（可根据需要调整）
  colors <- c(
    "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3",
    "#FDB462", "#B3DE69", "#FCCDE5", "#D9D9D9", "#BC80BD",
    "#A6CEE3", "#1F78B4", "#B2DF8A", "#33A02C", "#FB9A99",
    "#E31A1C", "#FDBF6F", "#FF7F00", "#CAB2D6", "#6A3D9A",
    "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854",
    "#FFD92F", "#E5C494", "#B3B3B3", "#F781BF", "#999999"
  )
  if (length(unique_classes) > length(colors)) {
    colors <- rep(colors, length.out = length(unique_classes))
  }
  color_mapping <- setNames(colors[1:length(unique_classes)], unique_classes)
  return(color_mapping)
}

# 3. 计算统一的x轴范围（基于所有组TOP30的logFC）----------------------------
calculate_unified_xlim <- function(file_paths, class_mapping) {
  all_logFC <- c()
  for (file in file_paths) {
    if (file.exists(file)) {
      data <- read.delim(file, header = TRUE, stringsAsFactors = FALSE)
      data_unified <- data %>%
        left_join(class_mapping, by = "compounds") %>%
        mutate(class = ifelse(is.na(unified_class), class, unified_class)) %>%
        select(-unified_class)
      
      top30 <- data_unified %>%
        mutate(abs_logFC = abs(logFC)) %>%
        arrange(desc(abs_logFC)) %>%
        head(30)
      
      all_logFC <- c(all_logFC, top30$logFC)
    }
  }
  max_abs <- max(abs(all_logFC))
  unified_limit <- max_abs * 1.1  # 扩大10%留白
  return(c(-unified_limit, unified_limit))
}

# 4. 创建并保存单个组别的TOP30条形图 ----------------------------------------
create_and_save_plot <- function(file_path, class_mapping, color_mapping, xlim) {
  group_name <- file_path_sans_ext(basename(file_path))
  
  data <- read.delim(file_path, header = TRUE, stringsAsFactors = FALSE)
  
  data_unified <- data %>%
    left_join(class_mapping, by = "compounds") %>%
    mutate(class = ifelse(is.na(unified_class), class, unified_class)) %>%
    select(-unified_class)
  
  # 筛选TOP30（按绝对logFC排序）
  top30 <- data_unified %>%
    mutate(abs_logFC = abs(logFC)) %>%
    arrange(desc(abs_logFC)) %>%
    head(30)
  
  # 在每个分类内按logFC排序
  top30_sorted <- top30 %>%
    group_by(class) %>%
    arrange(logFC, .by_group = TRUE) %>%
    ungroup()
  
  # 设置因子顺序，使条形图按排序显示
  top30_sorted$compounds <- factor(top30_sorted$compounds,
                                   levels = top30_sorted$compounds)
  
  p <- ggplot(top30_sorted, aes(x = logFC, y = compounds, fill = class)) +
    geom_bar(stat = "identity", alpha = 0.9) +
    scale_fill_manual(values = color_mapping) +
    coord_cartesian(xlim = xlim) +
    labs(
      title = group_name,
      x = "log2FC",
      y = NULL,
      fill = "分类"
    ) +
    theme_classic() +
    theme(
      plot.title = element_text(hjust = 0.5, size = 12, face = "bold"),
      axis.title.x = element_text(size = 10),
      axis.text.y = element_text(size = 6),         # 可根据需要调整
      axis.text.x = element_text(size = 8),
      legend.position = "bottom",                   # 每个图自带图例
      legend.title = element_text(size = 8),
      legend.text = element_text(size = 7),
      panel.grid.major.x = element_line(color = "grey90", size = 0.3),
      panel.border = element_rect(color = "black", fill = NA, size = 0.5),
      plot.margin = margin(5, 5, 5, 15)             # 左侧边距预留
    ) +
    geom_vline(xintercept = 0, linetype = "solid", color = "grey50", size = 0.3)
  
  # 在R中显示
  print(p)
  
  # 保存为PDF和PNG
  ggsave(paste0(group_name, "_top30.pdf"), p, width = 8, height = 10, limitsize = FALSE)
  ggsave(paste0(group_name, "_top30.png"), p, width = 8, height = 10, dpi = 300, limitsize = FALSE)
  
  cat("已保存:", group_name, "_top30.pdf/png\n")
  
  return(p)  # 返回ggplot对象（可选）
}

# 5. 执行主流程 ------------------------------------------------------------
cat("开始处理...\n")

# 创建分类映射
class_mapping <- create_unified_class_mapping(group_files)
color_mapping <- create_color_mapping(class_mapping)

# 计算统一x轴范围
xlim <- calculate_unified_xlim(group_files, class_mapping)
cat("统一x轴范围:", round(xlim[1], 2), "~", round(xlim[2], 2), "\n")

# 遍历每个文件，生成并保存图形
all_plots <- list()
for (file in group_files) {
  if (file.exists(file)) {
    p <- create_and_save_plot(file, class_mapping, color_mapping, xlim)
    group_name <- file_path_sans_ext(basename(file))
    all_plots[[group_name]] <- p
  } else {
    warning("文件不存在:", file)
  }
}

# 6. 保存分类映射表
write.csv(class_mapping, "统一分类映射表.csv", row.names = FALSE)
cat("分类映射表已保存: 统一分类映射表.csv\n")

# 7. 创建分类统计汇总（各组TOP30中各类别计数）
class_summary <- data.frame()
for (file in group_files) {
  if (file.exists(file)) {
    group_name <- file_path_sans_ext(basename(file))
    data <- read.delim(file, header = TRUE, stringsAsFactors = FALSE)
    data_unified <- data %>%
      left_join(class_mapping, by = "compounds") %>%
      mutate(class = ifelse(is.na(unified_class), class, unified_class))
    
    top30 <- data_unified %>%
      mutate(abs_logFC = abs(logFC)) %>%
      arrange(desc(abs_logFC)) %>%
      head(30)
    
    class_counts <- as.data.frame(table(top30$class))
    colnames(class_counts) <- c("Class", "Count")
    class_counts$Group <- group_name
    class_summary <- rbind(class_summary, class_counts)
  }
}

# 转换为宽格式
class_summary_wide <- class_summary %>%
  pivot_wider(names_from = Group, values_from = Count, values_fill = 0)

write.csv(class_summary_wide, "所有组别分类统计汇总.csv", row.names = FALSE)
cat("分类统计汇总已保存: 所有组别分类统计汇总.csv\n")

cat("全部完成！\n")

