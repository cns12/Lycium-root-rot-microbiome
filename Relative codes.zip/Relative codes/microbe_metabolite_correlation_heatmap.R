# 加载必要的包
library(ComplexHeatmap)
library(circlize)
library(tidyverse)
library(reshape2)

# 读取数据
microbe_data <- read.delim("细菌真菌差异属.txt", header = TRUE, row.names = 1, check.names = FALSE)
metabolite_data <- read.delim("差异物质所有组.txt", header = TRUE, row.names = 1, check.names = FALSE)

# 查看数据结构
cat("微生物数据维度:", dim(microbe_data), "\n")
cat("代谢物数据维度:", dim(metabolite_data), "\n")

# 确保两个数据集的列名一致
common_samples <- intersect(colnames(microbe_data), colnames(metabolite_data))
microbe_common <- microbe_data[, common_samples, drop = FALSE]
metabolite_common <- metabolite_data[, common_samples, drop = FALSE]

cat("共有样本数量:", length(common_samples), "\n")
cat("微生物特征数量:", nrow(microbe_common), "\n")
cat("代谢物特征数量:", nrow(metabolite_common), "\n")

# 使用所有的微生物和代谢物（不进行任何筛选）
microbe_selected <- microbe_common
metabolite_selected <- metabolite_common

# 转置数据以便计算相关性
microbe_t <- t(microbe_selected)
metabolite_t <- t(metabolite_selected)

# 计算Spearman相关性矩阵
tryCatch({
  correlation_matrix <- cor(metabolite_t, microbe_t, method = "spearman", use = "complete.obs")
  
  # 转置相关性矩阵，使微生物在行，代谢物在列
  correlation_matrix_t <- t(correlation_matrix)
  
  # 创建颜色映射函数
  col_fun <- colorRamp2(
    c(-1, 0, 1), 
    c("blue", "white", "red")
  )
  
  # 自定义单元格函数，只对|r| >= 0.3的单元格填充颜色
  cell_fun <- function(j, i, x, y, width, height, fill) {
    r <- correlation_matrix_t[i, j]
    if (abs(r) >= 0.4) {
      # 对于显著相关性，使用颜色填充
      grid.rect(x = x, y = y, width = width, height = height, 
                gp = gpar(fill = col_fun(r), col = "black", lwd = 0.5))
    } else {
      # 对于不显著相关性，使用白色填充
      grid.rect(x = x, y = y, width = width, height = height, 
                gp = gpar(fill = "white", col = "black", lwd = 0.5))
    }
  }
  
  # 根据特征数量调整方格尺寸和热图长宽比例
  n_microbes <- nrow(microbe_selected)        # 行数（微生物）
  n_metabolites <- nrow(metabolite_selected)  # 列数（代谢物）
  
  # 计算特征比例，确定热图的长宽比例
  ratio <- n_microbes / n_metabolites
  
  # 根据特征数量动态调整方格大小 - 减小方格尺寸以显示更多内容
  total_features <- n_microbes + n_metabolites
  
  if (total_features <= 60) {
    base_size <- 0.6
  } else if (total_features <= 100) {
    base_size <- 0.4
  } else if (total_features <= 150) {
    base_size <- 0.3
  } else if (total_features <= 200) {
    base_size <- 0.2
  } else {
    base_size <- 0.15  # 特征很多时使用更小的方格
  }
  
  # 根据比例调整行和列的方格大小
  if (ratio > 1.5) {
    # 微生物远多于代谢物，使热图更高
    row_height <- base_size * 0.9
    col_width <- base_size * 1.1
  } else if (ratio < 0.67) {
    # 代谢物远多于微生物，使热图更宽
    row_height <- base_size * 1.1
    col_width <- base_size * 0.9
  } else {
    # 比例接近，使用相同的方格大小
    row_height <- base_size
    col_width <- base_size
  }
  
  # 进一步减小字体大小以适应更多特征
  row_font_size <- max(4, 150 / n_microbes)      # 行(微生物)字体
  col_font_size <- max(4, 150 / n_metabolites)   # 列(代谢物)字体
  
  cat("热图尺寸:", n_microbes, "行(微生物) x", n_metabolites, "列(代谢物)\n")
  cat("特征比例:", round(ratio, 2), "\n")
  cat("行方格高度:", row_height, "cm\n")
  cat("列方格宽度:", col_width, "cm\n")
  cat("行字体大小:", row_font_size, "\n")
  cat("列字体大小:", col_font_size, "\n")
  
  # 创建热图 - 微生物在行，代谢物在列
  # 调整代谢物标签方向，使其旋转45度，避免重叠
  ht <- Heatmap(
    correlation_matrix_t,
    name = "相关系数",
    col = col_fun,
    rect_gp = gpar(col = "black", lwd = 0.5),
    cluster_rows = TRUE,
    cluster_columns = TRUE,
    show_row_names = TRUE,
    show_column_names = TRUE,
    row_names_gp = gpar(fontsize = row_font_size),
    column_names_gp = gpar(fontsize = col_font_size, rot = 45),  # 代谢物标签旋转45度
    row_names_max_width = unit(15, "cm"),
    column_names_max_height = unit(15, "cm"),
    heatmap_legend_param = list(
      title = "相关系数",
      title_position = "leftcenter-rot",
      legend_height = unit(3, "cm"),
      at = c(-1, -0.5, 0, 0.5, 1),
      labels = c("-1.0", "-0.5", "0", "0.5", "1.0")
    ),
    width = unit(ncol(correlation_matrix_t) * col_width, "cm"),
    height = unit(nrow(correlation_matrix_t) * row_height, "cm"),
    cell_fun = cell_fun
  )
  
  # 保存热图为PDF文件，确保完整显示
  pdf(paste0("全量微生物-代谢物相关性热图_", n_microbes, "x", n_metabolites, ".pdf"), 
      width = max(8, n_metabolites * col_width / 2.54 + 2), 
      height = max(8, n_microbes * row_height / 2.54 + 2))
  
  # 绘制热图
  draw(ht, 
       heatmap_legend_side = "right", 
       annotation_legend_side = "right",
       column_title = paste("全量微生物-代谢物Spearman相关性热图\n",
                            "微生物:", n_microbes, "个，代谢物:", n_metabolites, "个\n",
                            "(|r| ≥ 0.4显示颜色)"),
       column_title_gp = gpar(fontsize = 10, fontface = "bold"))
  
  dev.off()
  
  cat("热图已保存为PDF文件\n")
  
  # 同时尝试在R中显示（如果特征太多可能仍然显示不全）
  # 创建热图对象
  ht_display <- Heatmap(
    correlation_matrix_t,
    name = "相关系数",
    col = col_fun,
    rect_gp = gpar(col = "black", lwd = 0.5),
    cluster_rows = TRUE,
    cluster_columns = TRUE,
    show_row_names = TRUE,
    show_column_names = TRUE,
    row_names_gp = gpar(fontsize = row_font_size),
    column_names_gp = gpar(fontsize = col_font_size, rot = 45),  # 代谢物标签旋转45度
    row_names_max_width = unit(15, "cm"),
    column_names_max_height = unit(15, "cm"),
    heatmap_legend_param = list(
      title = "相关系数",
      title_position = "leftcenter-rot",
      legend_height = unit(3, "cm"),
      at = c(-1, -0.5, 0, 0.5, 1),
      labels = c("-1.0", "-0.5", "0", "0.5", "1.0")
    ),
    width = unit(ncol(correlation_matrix_t) * col_width, "cm"),
    height = unit(nrow(correlation_matrix_t) * row_height, "cm"),
    cell_fun = cell_fun
  )
  
  # 尝试在R中绘制热图
  tryCatch({
    draw(ht_display, 
         heatmap_legend_side = "right", 
         annotation_legend_side = "right",
         column_title = paste("全量微生物-代谢物Spearman相关性热图\n",
                              "微生物:", n_microbes, "个，代谢物:", n_metabolites, "个\n",
                              "(|r| ≥ 0.4显示颜色)"),
         column_title_gp = gpar(fontsize = 10, fontface = "bold"))
  }, error = function(e) {
    cat("在R中显示热图时出错:", e$message, "\n")
    cat("请查看保存的PDF文件以获取完整热图\n")
  })
  
  # 保存转置后的相关性矩阵
  write.csv(correlation_matrix_t, "all_spearman_correlation_matrix_transposed.csv")
  
  # 提取所有相关性对（基于转置矩阵）
  correlation_melted <- melt(correlation_matrix_t)
  colnames(correlation_melted) <- c("Microbe", "Metabolite", "Correlation")
  all_corr <- correlation_melted[order(abs(correlation_melted$Correlation), decreasing = TRUE), ]
  
  write.csv(all_corr, "all_spearman_correlation_pairs.csv", row.names = FALSE)
  cat("找到", nrow(all_corr), "个相关性对\n")
  
  # 筛选出显著的相关性对 (|r| >= 0.3)
  significant_corr <- all_corr[abs(all_corr$Correlation) >= 0.4, ]
  cat("显著相关性对数量 (|r| >= 0.4):", nrow(significant_corr), "\n")
  
  if (nrow(significant_corr) > 0) {
    write.csv(significant_corr, "all_significant_spearman_correlation_pairs.csv", row.names = FALSE)
    
    # 计算正负相关性数量
    positive_corr <- sum(significant_corr$Correlation > 0)
    negative_corr <- sum(significant_corr$Correlation < 0)
    cat("正相关性数量:", positive_corr, "\n")
    cat("负相关性数量:", negative_corr, "\n")
  }
  
}, error = function(e) {
  cat("分析出错:", e$message, "\n")
})

cat("全量Spearman相关性分析完成！\n")

