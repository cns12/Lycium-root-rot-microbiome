# 加载必要的包
library(ggplot2)
library(dplyr)
library(tidyr)
library(vegan)
library(ggrepel)

# 读取NMDS数据
nmds_data <- read.delim("nmds_sites.txt", header = TRUE, sep = "\t", stringsAsFactors = FALSE)

# 查看数据结构
head(nmds_data)
str(nmds_data)

# 提取样本名称和NMDS坐标
sample_names <- nmds_data$Sample
nmds_scores <- data.frame(
  Sample = nmds_data$Sample,
  NMDS1 = nmds_data$NMDS1,
  NMDS2 = nmds_data$NMDS2
)

# 创建分组信息 - 根据样本名称前缀
groups <- case_when(
  grepl("^SC-P-F-", sample_names) ~ "SC-P-F",
  grepl("^SC-P-", sample_names) ~ "SC-P", 
  grepl("^SC-F-", sample_names) ~ "SC-F",
  grepl("^P-F-", sample_names) ~ "P-F",
  grepl("^SC-", sample_names) ~ "SC",
  grepl("^P-", sample_names) ~ "P",
  grepl("^F-", sample_names) ~ "F",
  grepl("^CK-", sample_names) ~ "CK",
  TRUE ~ "Other"
)

# 添加分组信息到NMDS数据
nmds_scores$Group <- factor(groups)

# 检查分组情况
table(nmds_scores$Group)

# ===== 定义颜色方案 =====

# 专业配色方案
nmds_colors <- c(
  "SC-P-F" = "#E31A1C", "SC-P" = "#1F78B4", "SC-F" = "#33A02C",
  "P-F" = "#6A3D9A", "SC" = "#FF7F00", "P" = "#B2DF8A",
  "F" = "#B15928", "CK" = "#A6CEE3"
)

# ===== 定义主题 =====

nmds_theme <- theme(
  aspect.ratio = 1,
  panel.border = element_rect(colour = "black", fill = NA, size = 1),
  panel.grid.major = element_line(color = "grey95"),
  panel.grid.minor = element_blank(),
  legend.position = "right",
  plot.title = element_text(hjust = 0.5, size = 14, face = "bold"),
  plot.subtitle = element_text(hjust = 0.5, size = 10),
  legend.text = element_text(size = 9),
  legend.title = element_text(size = 11, face = "bold"),
  legend.key = element_rect(fill = "white")
)

# ===== 基础NMDS图 =====

p_base <- ggplot(nmds_scores, aes(x = NMDS1, y = NMDS2, color = Group, fill = Group)) +
  geom_point(size = 3, alpha = 0.8) +
  stat_ellipse(level = 0.95, type = "norm", alpha = 0.2, geom = "polygon") +
  labs(title = "NMDS Analysis",
       subtitle = "Non-metric Multidimensional Scaling",
       x = "NMDS1",
       y = "NMDS2",
       color = "Treatment Group",
       fill = "Treatment Group") +
  theme_minimal() +
  scale_color_manual(values = nmds_colors) +
  scale_fill_manual(values = nmds_colors) +
  nmds_theme

print(p_base)

# ===== 带组中心点的NMDS图 =====

# 计算各组中心点
group_centroids <- nmds_scores %>%
  group_by(Group) %>%
  summarise(
    NMDS1_mean = mean(NMDS1),
    NMDS2_mean = mean(NMDS2),
    n = n()
  )

p_centroids <- ggplot(nmds_scores, aes(x = NMDS1, y = NMDS2, color = Group)) +
  geom_point(size = 2.5, alpha = 0.7) +
  # 添加组中心点
  geom_point(data = group_centroids, 
             aes(x = NMDS1_mean, y = NMDS2_mean), 
             size = 5, shape = 18, alpha = 0.9) +
  # 添加组标签
  geom_text_repel(data = group_centroids,
                  aes(x = NMDS1_mean, y = NMDS2_mean, label = Group),
                  size = 4, fontface = "bold", box.padding = 0.8) +
  stat_ellipse(level = 0.95, type = "norm", alpha = 0.1, size = 0.8) +
  labs(title = "NMDS Plot with Group Centroids",
       subtitle = "Large diamonds show group centers with group labels",
       x = "NMDS1",
       y = "NMDS2") +
  theme_minimal() +
  scale_color_manual(values = nmds_colors) +
  nmds_theme

print(p_centroids)

# ===== 凸包NMDS图 =====

p_convex <- ggplot(nmds_scores, aes(x = NMDS1, y = NMDS2, color = Group, fill = Group)) +
  geom_point(size = 3, alpha = 0.8) +
  # 使用凸包
  geom_polygon(data = nmds_scores %>% 
                 group_by(Group) %>% 
                 slice(chull(NMDS1, NMDS2)), 
               alpha = 0.2, size = 0.5) +
  labs(title = "NMDS Plot with Convex Hulls",
       subtitle = "Convex hulls show group boundaries",
       x = "NMDS1",
       y = "NMDS2") +
  theme_minimal() +
  scale_color_manual(values = nmds_colors) +
  scale_fill_manual(values = nmds_colors) +
  nmds_theme

print(p_convex)

# ===== 统计分析 =====

# 由于没有原始距离矩阵，我们基于NMDS坐标进行PERMANOVA分析
cat("=== NMDS统计分析 ===\n")

# 基于NMDS坐标计算欧氏距离矩阵
nmds_dist <- dist(nmds_scores[, c("NMDS1", "NMDS2")])

# 执行PERMANOVA
permanova_result <- adonis2(nmds_dist ~ Group, data = nmds_scores)
print(permanova_result)

# 提取统计结果
r_squared <- permanova_result$R2[1]
p_value <- permanova_result$`Pr(>F)`[1]

# ===== 带统计结果的NMDS图 =====

p_stats <- ggplot(nmds_scores, aes(x = NMDS1, y = NMDS2, color = Group, fill = Group)) +
  geom_point(size = 3, alpha = 0.8) +
  stat_ellipse(level = 0.95, type = "norm", alpha = 0.2, geom = "polygon") +
  labs(title = "NMDS Analysis with Statistical Results",
       subtitle = paste0("PERMANOVA: R² = ", round(r_squared, 3), 
                         ", p = ", format.pval(p_value, digits = 2, eps = 0.001)),
       x = "NMDS1",
       y = "NMDS2",
       caption = "Based on Euclidean distance from NMDS coordinates") +
  theme_minimal() +
  scale_color_manual(values = nmds_colors) +
  scale_fill_manual(values = nmds_colors) +
  nmds_theme +
  theme(plot.caption = element_text(size = 8, face = "italic"))

print(p_stats)

# ===== 分组趋势分析 =====

# 计算组间距离矩阵
calculate_group_distances <- function(scores) {
  centroids <- scores %>%
    group_by(Group) %>%
    summarise(
      NMDS1_mean = mean(NMDS1),
      NMDS2_mean = mean(NMDS2)
    )
  
  distances <- as.matrix(dist(centroids[, c("NMDS1_mean", "NMDS2_mean")]))
  rownames(distances) <- centroids$Group
  colnames(distances) <- centroids$Group
  return(distances)
}

group_distances <- calculate_group_distances(nmds_scores)
cat("\n组间中心点距离:\n")
print(group_distances)

# ===== 样本分布密度图 =====

p_density <- ggplot(nmds_scores, aes(x = NMDS1, y = NMDS2, color = Group)) +
  geom_point(size = 2, alpha = 0.7) +
  stat_density_2d(aes(fill = Group), alpha = 0.1, geom = "polygon") +
  labs(title = "NMDS with Density Contours",
       subtitle = "Contour lines show sample density distribution",
       x = "NMDS1",
       y = "NMDS2") +
  theme_minimal() +
  scale_color_manual(values = nmds_colors) +
  scale_fill_manual(values = nmds_colors) +
  nmds_theme

print(p_density)

# ===== 保存所有图形 =====

ggsave("NMDS_base_plot.png", p_base, width = 10, height = 8, dpi = 300)
ggsave("NMDS_with_centroids.png", p_centroids, width = 10, height = 8, dpi = 300)
ggsave("NMDS_convex_hulls.png", p_convex, width = 10, height = 8, dpi = 300)
ggsave("NMDS_statistical_results.png", p_stats, width = 10, height = 8, dpi = 300)
ggsave("NMDS_density_contours.png", p_density, width = 10, height = 8, dpi = 300)

# ===== 输出统计结果 =====

# 计算各组统计信息
group_stats <- nmds_scores %>%
  group_by(Group) %>%
  summarise(
    n = n(),
    NMDS1_mean = mean(NMDS1),
    NMDS1_sd = sd(NMDS1),
    NMDS2_mean = mean(NMDS2),
    NMDS2_sd = sd(NMDS2),
    NMDS1_range = max(NMDS1) - min(NMDS1),
    NMDS2_range = max(NMDS2) - min(NMDS2)
  )

cat("\n=== 各组统计信息 ===\n")
print(group_stats)

# 保存统计结果
write.csv(group_stats, "NMDS_group_statistics.csv", row.names = FALSE)

# 保存PERMANOVA结果
permanova_df <- data.frame(
  Method = "PERMANOVA",
  R_squared = r_squared,
  P_value = p_value,
  Formula = "nmds_dist ~ Group"
)
write.csv(permanova_df, "NMDS_PERMANOVA_results.csv", row.names = FALSE)

# 保存组间距离矩阵
write.csv(as.data.frame(as.table(group_distances)), 
          "NMDS_group_distances.csv", row.names = FALSE)

# ===== 结果解读 =====

cat("\n=== NMDS分析结果解读 ===\n")
cat("1. 样本分布模式:\n")
cat("   - 各组在NMDS空间中的分布位置\n")
cat("   - 组内样本的聚集程度\n")
cat("   - 组间重叠或分离的程度\n\n")

cat("2. 统计显著性:\n")
cat(sprintf("   - PERMANOVA R² = %.3f (组间差异解释的比例)\n", r_squared))
cat(sprintf("   - p-value = %s (组间差异的显著性)\n", format.pval(p_value, digits = 2, eps = 0.001)))
cat("\n")

cat("3. 生物学意义:\n")
cat("   - NMDS1和NMDS2轴可能代表不同的生态/生物学梯度\n")
cat("   - 沿特定轴的分布可能对应特定的环境因子或处理效应\n")
cat("   - 对照组(CK)的位置可作为参考基准\n")

# 检查分离度
separation_score <- mean(group_distances[upper.tri(group_distances)]) / 
  (mean(group_stats$NMDS1_range) + mean(group_stats$NMDS2_range))

cat(sprintf("\n组间分离度评分: %.3f\n", separation_score))
if(separation_score > 0.5) {
  cat("✅ 各组分离度良好\n")
} else if(separation_score > 0.3) {
  cat("⚠️  各组有部分分离\n")
} else {
  cat("❌ 各组分离度较低\n")
}

cat("\nNMDS分析完成！所有图形和统计结果已保存。\n")

