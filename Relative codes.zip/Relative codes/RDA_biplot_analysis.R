# ===========================================================================
# 完整RDA分析代码（代谢物作为环境变量，细菌真菌属作为响应变量）
# 功能：合并重复代谢物类别，RDA分析，图形显示前N个重要代谢物（自定义颜色，避开黄色）
#       代谢物箭头为三角形，图例用三角形表示，显示重要属标签，无置信椭圆
# ===========================================================================

# 1. 加载必要的包
library(vegan)
library(ggplot2)
library(ggrepel)
library(ggnewscale)

# 2. 完全重置图形环境
graphics.off()

# 3. 定义文件名
metabolite_file <- "代谢物分类.txt"
genus_file <- "细菌真菌差异属-1.txt"

# 4. 读取并预处理代谢物数据 ---------------------------------------------
# 先不指定行名读取（因为第一列有重复类别名）
metabolite_raw <- read.delim(metabolite_file, header = TRUE, check.names = FALSE)

# 提取第一列作为类别名，其余列为数值数据
class_names <- metabolite_raw[, 1]
metabolite_values <- metabolite_raw[, -1]

# 输出合并前后的类别数量
cat("原始代谢物数据行数（含重复类别）:", nrow(metabolite_raw), "\n")
cat("唯一代谢物类别数:", length(unique(class_names)), "\n")

# 按类别名分组求和（合并相同类别的行）
metabolite_combined <- rowsum(metabolite_values, group = class_names)

cat("合并后数据行数（唯一类别）:", nrow(metabolite_combined), "\n")

# 转置，使样本为行，代谢物类别为列
metabolite_data <- as.data.frame(t(metabolite_combined))

# 5. 读取并预处理细菌真菌差异属数据 ---------------------------------------
# 原始数据：行为属，列为样本。需要转置使样本为行。
genus_raw <- read.delim(genus_file, header = TRUE, row.names = 1, check.names = FALSE)
genus_data <- as.data.frame(t(genus_raw))

# 6. 提取样本分组信息（从样本名中提取组名）--------------------------------
extract_group <- function(sample_names) {
  # 假设样本名格式如 SC-P-F-1，去掉末尾的数字和可能的横线得到组名
  groups <- sub("-[0-9]+$", "", sample_names)
  groups <- sub("-$", "", groups)
  return(groups)
}
sample_groups <- extract_group(rownames(metabolite_data))

# 7. 确保两个数据集的样本顺序一致 ----------------------------------------
common_samples <- intersect(rownames(metabolite_data), rownames(genus_data))
if (length(common_samples) == 0) {
  stop("错误：代谢物数据和属数据中没有共同的样本！")
}
metabolite_data <- metabolite_data[common_samples, , drop = FALSE]
genus_data <- genus_data[common_samples, , drop = FALSE]
sample_groups <- sample_groups[match(common_samples, rownames(metabolite_data))]

# 8. 对物种数据进行Hellinger转换（适用于群落数据）------------------------
genus_hell <- decostand(genus_data, "hellinger")

# 9. 代谢物数据作为环境变量（确保全为数值）-------------------------------
metabolite_numeric <- metabolite_data[, sapply(metabolite_data, is.numeric), drop = FALSE]
if (ncol(metabolite_numeric) == 0) {
  stop("错误：代谢物数据中没有数值型列！")
}

# 对代谢物数据进行标准化（均值为0，方差为1），使各变量尺度一致
metabolite_std <- decostand(metabolite_numeric, "standardize")

# 10. RDA分析 ----------------------------------------------------------
rda_result <- rda(genus_hell ~ ., data = metabolite_std)

# 11. 提取轴解释的方差百分比 -------------------------------------------
rda_summary <- summary(rda_result)
rda1_percent <- round(100 * rda_summary$cont$importance[2, 1], 1)
rda2_percent <- round(100 * rda_summary$cont$importance[2, 2], 1)

# 12. 统计检验 ---------------------------------------------------------
# 整体模型显著性
model_sig <- anova(rda_result, permutations = 999)
# 每个环境因子（代谢物）的显著性
env_sig <- anova(rda_result, by = "margin", permutations = 999)

# 13. 提取RDA结果用于后续绘图和输出 ------------------------------------
# 环境因子（代谢物）在RDA轴上的坐标（箭头）
env_scores <- scores(rda_result, display = "bp")
# 物种（属）在RDA轴上的坐标
species_scores <- scores(rda_result, display = "species")
# 样本点在RDA轴上的坐标
site_scores <- scores(rda_result, display = "sites")

# 14. 生成分析报告（函数定义）------------------------------------------
generate_rda_report <- function(rda_result, env_scores, model_sig, env_sig, rda1_percent, rda2_percent) {
  report <- c(
    "RDA分析结果报告（代谢物作为环境变量）",
    "=========================================",
    "",
    paste("分析时间:", Sys.time()),
    "",
    "1. 模型整体信息",
    paste("   - RDA1解释方差:", rda1_percent, "%"),
    paste("   - RDA2解释方差:", rda2_percent, "%"),
    paste("   - 累计解释方差 (RDA1+RDA2):", round(rda1_percent + rda2_percent, 1), "%"),
    paste("   - 模型显著性 (p-value):", model_sig$`Pr(>F)`[1]),
    "",
    "2. 代谢物重要性排序",
    "   (按对微生物群落变异的解释力从高到低)"
  )
  
  # 计算环境因子的解释力（箭头长度）
  env_importance <- sqrt(env_scores[,1]^2 + env_scores[,2]^2)
  env_importance <- sort(env_importance, decreasing = TRUE)
  
  for(i in 1:length(env_importance)) {
    env_name <- names(env_importance)[i]
    p_value <- env_sig$`Pr(>F)`[which(rownames(env_sig) == env_name)]
    report <- c(report, 
                paste("   ", i, ".", env_name, 
                      ": 影响强度 =", round(env_importance[i], 3),
                      ", p-value =", round(p_value, 4)))
  }
  
  report <- c(report,
              "",
              "3. 代谢物之间的关系",
              "   (基于箭头夹角判断)"
  )
  
  if(nrow(env_scores) > 1) {
    for(i in 1:(nrow(env_scores)-1)) {
      for(j in (i+1):nrow(env_scores)) {
        env1 <- rownames(env_scores)[i]
        env2 <- rownames(env_scores)[j]
        cos_angle <- sum(env_scores[i,] * env_scores[j,]) / 
          (sqrt(sum(env_scores[i,]^2)) * sqrt(sum(env_scores[j,]^2)))
        relation <- ifelse(cos_angle > 0.7, "强正相关",
                           ifelse(cos_angle > 0.3, "正相关",
                                  ifelse(cos_angle > -0.3, "弱相关或无相关",
                                         ifelse(cos_angle > -0.7, "负相关", "强负相关"))))
        report <- c(report, 
                    paste("   -", env1, "与", env2, ":", relation, 
                          "(夹角余弦值 =", round(cos_angle, 3), ")"))
      }
    }
  }
  
  report <- c(report,
              "",
              "4. 主要结论",
              paste("   - 最重要的代谢物驱动因子:", names(env_importance)[1]),
              paste("   - 模型解释力:", round(rda1_percent + rda2_percent, 1), "%"),
              paste("   - 统计显著性:", ifelse(model_sig$`Pr(>F)`[1] < 0.05, "显著", "不显著")),
              "",
              "5. 解读指南",
              "   - 箭头长度表示代谢物的影响力",
              "   - 箭头方向表示代谢物含量增加的方向", 
              "   - 样本点距离反映群落相似性",
              "   - 代谢物夹角反映它们之间的相关性"
  )
  return(report)
}

# 15. 生成并保存报告 ---------------------------------------------------
rda_report <- generate_rda_report(rda_result, env_scores, model_sig, env_sig, rda1_percent, rda2_percent)
writeLines(rda_report, "RDA_metabolite_report.txt")
cat("RDA分析报告已保存为 RDA_metabolite_report.txt\n")

# 16. 保存详细数据结果 -------------------------------------------------
# 代谢物得分（箭头坐标）
write.csv(env_scores, "RDA_metabolite_scores.csv")
cat("代谢物得分已保存为 RDA_metabolite_scores.csv\n")

# 物种得分（前100个最重要的属）
species_importance <- sqrt(rowSums(species_scores^2))
top_species <- order(species_importance, decreasing = TRUE)[1:min(100, nrow(species_scores))]
write.csv(species_scores[top_species, ], "RDA_genus_scores_top100.csv")
cat("重要属得分已保存为 RDA_genus_scores_top100.csv\n")

# 样本得分
write.csv(site_scores, "RDA_sample_scores.csv")
cat("样本得分已保存为 RDA_sample_scores.csv\n")

# 17. 保存统计检验结果 -------------------------------------------------
sink("RDA_metabolite_statistical_tests.txt")
cat("RDA统计检验结果（代谢物作为环境变量）\n")
cat("=========================================\n\n")
cat("1. 整体模型显著性检验:\n")
print(model_sig)
cat("\n2. 各代谢物显著性检验:\n")
print(env_sig)
sink()
cat("统计检验结果已保存为 RDA_metabolite_statistical_tests.txt\n")

# ===========================================================================
# 18. 绘图：显示重要代谢物（前N个），自定义颜色（避开黄色），三角形箭头，
#       图例用三角形表示，显示属标签，无置信椭圆
# ===========================================================================
tryCatch({
  # 设置要显示的代谢物数量（根据需要修改）
  top_metabolites <- 15  # 显示前10个最重要的代谢物，可改为其他数值
  
  # 转换坐标数据为数据框
  site_scores_df <- as.data.frame(site_scores)
  species_scores_df <- as.data.frame(species_scores)
  env_scores_df <- as.data.frame(env_scores)
  
  # 计算代谢物箭头长度，排序，筛选前top_metabolites个最重要的代谢物
  env_scores_df$Length <- sqrt(env_scores_df$RDA1^2 + env_scores_df$RDA2^2)
  env_scores_df <- env_scores_df[order(env_scores_df$Length, decreasing = TRUE), ]
  env_scores_top <- head(env_scores_df, top_metabolites)
  cat("显示前", top_metabolites, "个最重要的代谢物\n")
  
  # 只保留前5个最重要的属（可根据需要调整）
  species_lengths <- sqrt(rowSums(species_scores_df^2))
  top_species <- order(species_lengths, decreasing = TRUE)[1:min(5, length(species_lengths))]
  species_scores_top <- species_scores_df[top_species, ]
  species_scores_top$Genus <- rownames(species_scores_top)
  
  # 添加分组信息到样本点
  site_scores_df$Sample <- rownames(site_scores_df)
  site_scores_df$Group <- sample_groups[match(rownames(site_scores_df), rownames(metabolite_data))]
  
  # 准备代谢物箭头数据，添加变量名
  env_scores_top$Variable <- rownames(env_scores_top)
  
  # 计算缩放因子，使箭头长度适中
  max_site_range <- max(abs(site_scores_df[, c("RDA1", "RDA2")]))
  max_env_length <- max(sqrt(env_scores_top$RDA1^2 + env_scores_top$RDA2^2))
  mul_factor <- 0.8 * max_site_range / max_env_length
  env_scores_top$RDA1_scaled <- env_scores_top$RDA1 * mul_factor
  env_scores_top$RDA2_scaled <- env_scores_top$RDA2 * mul_factor
  
  # 定义自定义颜色向量（15色，避开黄色）
  my_colors <- c(
    "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00", "#A65628", 
    "#F781BF", "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3",
    "#A6D854", "#B3B3B3", "#FDB462"
  )
  # 确保颜色数量不少于要显示的代谢物数量
  used_colors <- my_colors[1:top_metabolites]
  
  # 绘图
  p <- ggplot() +
    # 样本点，按分组着色（使用默认颜色）
    geom_point(data = site_scores_df, 
               aes(x = RDA1, y = RDA2, color = Group), 
               size = 3, alpha = 0.7) +
    # 重要属箭头（统一蓝色）
    geom_segment(data = species_scores_top,
                 aes(x = 0, y = 0, xend = RDA1, yend = RDA2),
                 arrow = arrow(length = unit(0.15, "cm")),
                 color = "#1f77b4", alpha = 0.7, linewidth = 0.6) +
    # 属标签
    ggrepel::geom_text_repel(data = species_scores_top,
                             aes(x = RDA1, y = RDA2, label = Genus),
                             color = "#1f77b4", size = 4,
                             box.padding = 0.5, point.padding = 0.5,
                             max.overlaps = 20) +
    # 开始一个新的颜色标度，用于代谢物箭头（不影响分组颜色）
    ggnewscale::new_scale_color() +
    # 重要代谢物箭头（映射颜色，用于图例），箭头类型为实心三角形
    geom_segment(data = env_scores_top,
                 aes(x = 0, y = 0, xend = RDA1_scaled, yend = RDA2_scaled, color = Variable),
                 arrow = arrow(length = unit(0.2, "cm"), type = "closed"),  # 三角形箭头
                 linewidth = 0.8) +
    # 使用自定义颜色向量，图例两列显示，并覆盖图例标记为三角形（隐藏线段）
    scale_color_manual(values = used_colors, name = "Important Metabolites",
                       guide = guide_legend(ncol = 2, 
                                            override.aes = list(linetype = "blank", shape = 17))) +
    # 添加坐标轴参考线
    geom_hline(yintercept = 0, linetype = "dashed", alpha = 0.5) +
    geom_vline(xintercept = 0, linetype = "dashed", alpha = 0.5) +
    # 轴标签
    labs(x = paste0("RDA1 (", rda1_percent, "%)"),
         y = paste0("RDA2 (", rda2_percent, "%)"),
         title = "RDA双序图 - 代谢物与细菌真菌属的关系") +
    theme_bw() +
    theme(panel.grid = element_blank(),
          plot.title = element_text(hjust = 0.5),
          legend.key.size = unit(0.5, 'cm')) +
    coord_fixed(ratio = 1)
  
  # 显示并保存图形
  print(p)
  ggsave("RDA_metabolite_ggplot_biplot.png", p, width = 14, height = 14, dpi = 300)
  cat("ggplot2图形已保存为 RDA_metabolite_ggplot_biplot.png\n")
  
}, error = function(e) {
  cat("ggplot2图形创建失败:", e$message, "\n")
})

# 19. 完成提示 ---------------------------------------------------------
cat("\n=== RDA分析完成 ===\n")
cat("生成的文件:\n")
cat("1. RDA_metabolite_report.txt - 分析报告\n")
cat("2. RDA_metabolite_scores.csv - 代谢物坐标\n")
cat("3. RDA_genus_scores_top100.csv - 重要属坐标\n")
cat("4. RDA_sample_scores.csv - 样本坐标\n")
cat("5. RDA_metabolite_statistical_tests.txt - 统计检验结果\n")
cat("6. RDA_metabolite_ggplot_biplot.png - RDA图形（三角形箭头，图例为三角形）\n")

