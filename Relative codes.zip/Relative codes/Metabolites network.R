# 加载必要的包
library(tidyverse)
library(readr)
library(reshape2)

# ---------------------------
# 1. 数据读取与预处理
# ---------------------------
# 读取代谢物数据（TSV格式，第一列为代谢物名称）
metabolite_data <- read_tsv("Health-metabolism.txt", col_names = TRUE, quote = "")

# 将代谢物名称设为行名，并移除第一列
data <- metabolite_data %>%
  column_to_rownames("name") %>%  # 使用代谢物名称作为行名
  as.matrix()                    # 转换为矩阵以提高计算效率

# 转置数据：行=样本（H1-H6），列=代谢物（用于代谢物间的相关性分析）
t_data <- t(data)

# ---------------------------
# 2. 计算Spearman相关性矩阵
# ---------------------------
# 计算Spearman相关系数矩阵（处理缺失值：仅使用完整观测对）
cor_matrix <- cor(t_data, 
                  use = "complete.obs", 
                  method = "spearman")  # 修改为Spearman方法

# 筛选显著相关性：保留绝对值大于0.8的边（阈值可调）
cor_threshold <- 0.8
cor_matrix_filtered <- cor_matrix
cor_matrix_filtered[abs(cor_matrix) < cor_threshold] <- 0

# ---------------------------
# 3. 生成Gephi输入文件
# ---------------------------
# 生成节点文件（Nodes.csv）
nodes <- data.frame(
  Id = rownames(cor_matrix),     # 代谢物唯一标识
  Label = rownames(cor_matrix)   # 代谢物显示名称
)
write_csv(nodes, "nodes.csv")

# 生成边文件（Edges.csv）
edges <- cor_matrix_filtered %>%
  melt() %>%                      # 将矩阵转换为长格式
  as_tibble() %>%
  filter(Var1 != Var2, value != 0) %>%  # 移除自身相关性和零权重边
  rename(Source = Var1, Target = Var2, Weight = value) %>%
  mutate(Type = "Undirected")      # 定义边类型为无向

write_csv(edges, "edges.csv")

# ---------------------------
# 4. 可选：移除全零代谢物（如果数据中存在）
# ---------------------------
# 检查并移除在所有样本中值为零的代谢物
zero_metabolites <- rownames(data)[rowSums(data) == 0]
if (length(zero_metabolites) > 0) {
  data <- data[!rownames(data) %in% zero_metabolites, ]
  message("已移除全零代谢物：", paste(zero_metabolites, collapse = ", "))
}

