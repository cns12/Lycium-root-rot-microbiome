# ============================================================
# OPLS-DA 分析脚本 (R 语言)
# 适用于代谢组学、宏基因组学等数据
# 使用 ropls 包进行正交偏最小二乘判别分析
# ============================================================

# -------------------- 1. 安装和加载所需包 --------------------
packages <- c("ropls", "ggplot2", "readr", "dplyr", "tidyr")
installed <- installed.packages()
for (pkg in packages) {
  if (!(pkg %in% installed[, "Package"])) {
    install.packages(pkg, dependencies = TRUE)
  }
  library(pkg, character.only = TRUE)
}

# -------------------- 2. 读取数据 --------------------
# 假设数据格式：第一列为样本名（SampleID），最后一列为分组标签（Group）
# 中间列为代谢物/特征丰度（已归一化）
# 示例数据：data.csv (逗号分隔) 或 data.txt (制表符分隔)
# 请根据实际情况修改文件路径和分隔符
data <- read.csv("data.csv", header = TRUE, row.names = 1, check.names = FALSE)
# 或者 data <- read.table("data.txt", header = TRUE, row.names = 1, sep = "\t", check.names = FALSE)

# 检查数据结构
head(data)
dim(data)

# 提取分组信息（最后一列）
group <- as.factor(data[, ncol(data)])
# 提取特征矩阵（去掉最后一列）
X <- data[, -ncol(data)]
# 确保数据为数值型
X <- as.matrix(X)

cat("样本数:", nrow(X), " 特征数:", ncol(X), "\n")
cat("分组信息:\n")
print(table(group))

# -------------------- 3. 数据预处理 --------------------
# 3.1 缺失值处理（用最小值的一半填充，或均值填充）
# 这里用最小值的一半填充
X[is.na(X)] <- min(X, na.rm = TRUE) / 2

# 3.2 数据转换（可选：log2 或 log10 转换）
# 若数据为相对丰度或峰面积，建议 log 转换
X_log <- log2(X + 1)  # 加1避免对数零

# 3.3 标准化（Pareto scaling 是代谢组学常用方法）
# Pareto scaling: (x - mean) / sqrt(sd)
# 使用 ropls 自带的预处理函数
# 先中心化，再 Pareto 缩放
X_scaled <- scale(X_log, center = TRUE, scale = TRUE)  # 先标准化
# 再调整为 Pareto 缩放 (除以 sqrt(sd))
sd_vals <- apply(X_scaled, 2, sd)
X_pareto <- sweep(X_scaled, 2, sqrt(sd_vals), FUN = "/")

# 也可以直接用 ropls 的 scaling 参数，会在建模时自动处理，但这里为了演示手工处理

# -------------------- 4. OPLS-DA 建模 --------------------
# 使用 ropls 包的 opls 函数
# 参数：orthoI = 1 表示1个正交成分，通常先尝试1个
# crossvalI = 7 表示7折交叉验证
model <- opls(X_pareto, group, predI = 1, orthoI = 1, crossvalI = 7,
              log10L = TRUE,  # 输出详细信息
              scaleC = "pareto")  # 实际已在外部缩放，这里可以设为"none"

# 查看模型摘要
print(model)

# 提取模型参数
R2X <- model@summaryDF[1, "R2X"]
R2Y <- model@summaryDF[1, "R2Y"]
Q2 <- model@summaryDF[1, "Q2"]
cat("\n模型性能:\n")
cat("R2X =", R2X, " R2Y =", R2Y, " Q2 =", Q2, "\n")

# -------------------- 5. 模型验证（置换检验） --------------------
# 进行100次置换检验评估模型可靠性
perm_model <- getPermutationMatrix(model, nperm = 100)
# 绘制置换检验图
png("permutation_test.png", width = 800, height = 600)
plot(perm_model)
dev.off()
cat("置换检验图已保存为 permutation_test.png\n")

# -------------------- 6. 提取 VIP 值 --------------------
vip <- getVipVn(model)  # 返回每个特征的VIP值
vip_df <- data.frame(Feature = colnames(X_pareto), VIP = vip)
vip_df <- vip_df[order(vip_df$VIP, decreasing = TRUE), ]

# 筛选 VIP > 1 的特征（常用阈值）
vip_selected <- vip_df[vip_df$VIP > 1, ]
cat("\nVIP > 1 的特征数:", nrow(vip_selected), "\n")
print(head(vip_selected, 10))

# 保存 VIP 结果
write.csv(vip_df, "vip_values.csv", row.names = FALSE)

# -------------------- 7. 可视化：得分图 --------------------
# 提取预测成分和正交成分得分
score_df <- data.frame(
  SampleID = rownames(X_pareto),
  t1 = model@scoreMN[, 1],
  to1 = model@orthoScoreMN[, 1],
  Group = group
)

# 绘制得分图（t1 vs to1）
p_score <- ggplot(score_df, aes(x = t1, y = to1, color = Group)) +
  geom_point(size = 3, alpha = 0.7) +
  stat_ellipse(aes(fill = Group), type = "norm", alpha = 0.2, geom = "polygon") +
  labs(title = "OPLS-DA Score Plot",
       x = paste0("t[1] (", round(model@summaryDF[1, "R2X"] * 100, 1), "%)"),
       y = paste0("to[1] (", round(model@summaryDF[1, "R2Xo"] * 100, 1), "%)")) +
  theme_minimal() +
  theme(legend.position = "right")

ggsave("score_plot.png", p_score, width = 7, height = 5, dpi = 300)
cat("得分图已保存为 score_plot.png\n")

# -------------------- 8. 可视化：S-plot --------------------
# S-plot 展示载荷与相关性
loadings <- model@loadingMN[, 1]        # 预测成分载荷
corr_load <- model@cMN[, 1]             # 预测成分与变量的相关性
s_plot_df <- data.frame(Loadings = loadings, Correlation = corr_load, VIP = vip)

p_s <- ggplot(s_plot_df, aes(x = Loadings, y = Correlation, color = VIP)) +
  geom_point(alpha = 0.5) +
  scale_color_gradient(low = "blue", high = "red") +
  labs(title = "S-plot",
       x = "p[1] (Loadings)", y = "p(cor)[1]") +
  theme_minimal()
ggsave("s_plot.png", p_s, width = 7, height = 5, dpi = 300)
cat("S-plot 已保存为 s_plot.png\n")

# -------------------- 9. 可视化：VIP柱状图（Top20） --------------------
top20 <- head(vip_df, 20)
p_vip <- ggplot(top20, aes(x = reorder(Feature, VIP), y = VIP, fill = VIP)) +
  geom_bar(stat = "identity") +
  coord_flip() +
  labs(title = "Top 20 VIP Features", x = "Feature", y = "VIP") +
  scale_fill_gradient(low = "lightblue", high = "darkblue") +
  theme_minimal()
ggsave("vip_top20.png", p_vip, width = 7, height = 6, dpi = 300)
cat("VIP Top20 柱状图已保存为 vip_top20.png\n")

# -------------------- 10. 输出模型摘要到文本文件 --------------------
sink("oplsda_results.txt")
cat("OPLS-DA 模型结果\n")
cat("==================\n\n")
cat("模型性能:\n")
cat("R2X =", R2X, "\n")
cat("R2Y =", R2Y, "\n")
cat("Q2  =", Q2, "\n\n")
cat("VIP > 1 的特征列表 (前20):\n")
print(head(vip_selected, 20))
sink()

cat("\n分析完成！结果文件已生成：\n")
cat(" - oplsda_results.txt\n")
cat(" - vip_values.csv\n")
cat(" - permutation_test.png\n")
cat(" - score_plot.png\n")
cat(" - s_plot.png\n")
cat(" - vip_top20.png\n")