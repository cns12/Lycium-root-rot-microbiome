# 加载必要包
library(tidyr)
library(plspm)
library(ggplot2)
library(dplyr)
library(corrplot)

# 读取数据
df <- read.table("健康与发病-2.txt", header = TRUE, sep = "\t")

# 查看数据结构
cat("数据结构:\n")
str(df)
cat("\n前几行数据:\n")
print(head(df))

# ==================== 第一步：数据预处理 ====================

# 不再创建疾病等级变量，直接使用a,b,c,d作为反映型指标
# a=1: 健康, b=1: 发病等级1, c=1: 发病等级2, d=1: 发病等级3

# 检查疾病变量分布
cat("\n疾病变量分布:\n")
print(table(df$a, df$b, df$c, df$d))

# 处理列名中的空格（R会将空格转换为点）
names(df) <- gsub(" ", ".", names(df))
cat("\n处理后的列名:\n")
print(names(df))

# 检查缺失值并处理
if(any(is.na(df))) {
  for(col in names(df)) {
    if(any(is.na(df[[col]]))) {
      df[is.na(df[[col]]), col] <- median(df[[col]], na.rm = TRUE)
    }
  }
}

# ==================== 第二步：定义PLS-PM模型结构 ====================

# 根据变量分类定义潜变量区块
# 注意：顺序很重要，原因在前，结果在后
blocks <- list(
  SoilProperties = c("pH", "NH4.N", "NO3.N", "SOC", "TN"),
  SoilEnzyme = c("BG", "AG"),
  Microorganisms = c("Pseudomonas", "Fusarium"),
  PlantEnzyme = c("POD", "CAT", "MDA"),
  Metabolites = c("Jasmonic.acid", "Salicylic.acid", "Succinyhomoserine", "Cyclo.his.pro."),
  DiseaseLevel = c("a", "b", "c", "d")  # 使用原始的四个疾病指标
)

cat("\n========== PLS-PM模型潜变量区块 ==========\n")
print(blocks)

# ==================== 第三步：构建基于生物学逻辑的路径模型 ====================

# 模型3：全面模型
path_matrix3 <- rbind(
  SoilProperties = c(0, 0, 0, 0, 0, 0),
  Microorganisms = c(1, 0, 0, 0, 0, 0),  # 受土壤理化影响
  SoilEnzyme =    c(1, 1, 0, 0, 0, 0),   # 受土壤理化、微生物影响
  PlantEnzyme =   c(0, 1, 0, 0, 0, 0),   # 受所有前面因素影响
  Metabolites =   c(1, 1, 1, 1, 0, 0),   # 受土壤理化、微生物、土壤酶活影响
  DiseaseLevel =  c(1, 1, 1, 1, 1, 0)    # 受所有前面因素影响
)

cat("\n========== 模型3路径矩阵 (全面模型) ==========\n")
print(path_matrix3)

# 设置模式（所有变量为反映型）
modes <- rep("A", 6)

# ==================== 第四步：运行PLS-PM分析 ====================

# 运行模型
cat("\n正在运行PLS-PM模型...\n")
pls_result <- plspm(df, path_matrix3, blocks, modes = modes, 
                    scaled = TRUE, boot.val = TRUE, br = 200)  # 增加bootstrap验证

# ==================== 第五步：详细结果分析 ====================

cat("\n========== 模型结果汇总 ==========\n")
print(summary(pls_result))

# 1. 路径系数
cat("\n========== 路径系数 ==========\n")
path_coefs <- pls_result$path_coefs
print(path_coefs)

# 2. 外部模型（载荷和权重）
cat("\n========== 外部模型 ==========\n")
outer_model <- pls_result$outer_model
print(outer_model)

# 3. 内部模型R²
cat("\n========== 内模型R平方 ==========\n")
inner_summary <- pls_result$inner_summary
print(inner_summary[, "R2", drop = FALSE])

# ==================== 第六步：总效应分析 ====================

cat("\n========== 总效应分析 ==========\n")

# 稳健的总效应计算方法
calculate_total_effects <- function(path_matrix, max_iter = 10) {
  n <- nrow(path_matrix)
  total_effects <- path_matrix
  current_power <- path_matrix
  
  for(i in 2:max_iter) {
    current_power <- current_power %*% path_matrix
    # 如果效应变得很小，提前停止
    if(max(abs(current_power)) < 0.001) break
    total_effects <- total_effects + current_power
  }
  
  return(total_effects)
}

# 计算总效应
total_effects <- calculate_total_effects(path_coefs)

cat("总效应矩阵（包含直接和间接效应）:\n")
print(total_effects)

# 提取对疾病等级的总效应
disease_effects <- total_effects[, "DiseaseLevel", drop = FALSE]
disease_effects_df <- as.data.frame(disease_effects)
disease_effects_df$Factor <- rownames(disease_effects_df)
colnames(disease_effects_df) <- c("Total_Effect", "Factor")

# 移除疾病等级自身的效应（总是为0）
disease_effects_df <- disease_effects_df[disease_effects_df$Factor != "DiseaseLevel", ]

# 按总效应绝对值排序
disease_effects_df$Abs_Effect <- abs(disease_effects_df$Total_Effect)
disease_effects_df <- disease_effects_df[order(-disease_effects_df$Abs_Effect), ]
disease_effects_df$Abs_Effect <- NULL  # 移除辅助列

cat("\n对疾病等级的总效应排序:\n")
print(disease_effects_df)

# ==================== 第七步：可视化 ====================

# 1. 路径图
cat("\n生成路径图...\n")
inner_plot <- plot(pls_result, what = "inner", arr.width = 0.1)
title("PLS-PM路径模型 - 全面模型")

# 2. 载荷图
loadings_plot <- plot(pls_result, what = "loadings")
title("变量载荷图")

# 3. 权重图
weights_plot <- plot(pls_result, what = "weights")
title("变量权重图")

# 4. 自定义可视化

# 路径系数条形图
path_data <- as.data.frame(as.table(path_coefs))
colnames(path_data) <- c("From", "To", "Coefficient")
path_data <- path_data[path_data$Coefficient != 0 & path_data$From != path_data$To, ]

if(nrow(path_data) > 0) {
  p1 <- ggplot(path_data, aes(x = reorder(paste(From, "->", To), Coefficient), y = Coefficient, 
                              fill = Coefficient > 0)) +
    geom_bar(stat = "identity") +
    coord_flip() +
    scale_fill_manual(values = c("TRUE" = "steelblue", "FALSE" = "coral")) +
    labs(title = "路径系数",
         x = "路径", y = "系数值") +
    theme_minimal() +
    theme(legend.position = "none")
  print(p1)
}

# 总效应条形图
if(nrow(disease_effects_df) > 0) {
  p2 <- ggplot(disease_effects_df, aes(x = reorder(Factor, Total_Effect), y = Total_Effect, 
                                       fill = Total_Effect > 0)) +
    geom_bar(stat = "identity") +
    coord_flip() +
    scale_fill_manual(values = c("TRUE" = "darkgreen", "FALSE" = "red")) +
    labs(title = "对疾病等级的总效应",
         x = "因素", y = "总效应值") +
    theme_minimal() +
    theme(legend.position = "none")
  print(p2)
}

# 变量载荷热图
loading_matrix <- pls_result$outer_model %>%
  select(name, block, loading) %>%
  pivot_wider(names_from = block, values_from = loading, values_fill = 0) %>%
  as.data.frame()

rownames(loading_matrix) <- loading_matrix$name
loading_matrix$name <- NULL

# 创建热图
corrplot(as.matrix(loading_matrix), is.corr = FALSE, 
         method = "color", type = "full", 
         tl.cex = 0.8, tl.col = "black",
         title = "变量载荷热图", mar = c(0,0,1,0))

# 潜变量得分散点图
if(ncol(pls_result$scores) >= 2) {
  lv_scores <- as.data.frame(pls_result$scores)
  colnames(lv_scores) <- paste0("LV", 1:ncol(lv_scores))
  
  # 创建疾病状态变量用于着色
  lv_scores$DiseaseState <- ifelse(df$a == 1, "健康",
                                   ifelse(df$b == 1, "等级1",
                                          ifelse(df$c == 1, "等级2", 
                                                 ifelse(df$d == 1, "等级3", "未知"))))
  lv_scores$DiseaseState <- factor(lv_scores$DiseaseState, 
                                   levels = c("健康", "等级1", "等级2", "等级3"))
  
  p3 <- ggplot(lv_scores, aes(x = LV1, y = LV2, color = DiseaseState)) +
    geom_point(size = 3, alpha = 0.7) +
    labs(title = "潜变量得分散点图",
         x = "潜变量1",
         y = "潜变量2",
         color = "疾病状态") +
    theme_minimal() +
    scale_color_manual(values = c("健康" = "green", "等级1" = "yellow", 
                                  "等级2" = "orange", "等级3" = "red"))
  print(p3)
}

# 变量重要性图
lv_importance <- outer_model %>%
  group_by(block) %>%
  summarise(Mean_Loading = mean(abs(loading)), .groups = 'drop') %>%
  arrange(desc(Mean_Loading))

p4 <- ggplot(lv_importance, aes(x = reorder(block, Mean_Loading), y = Mean_Loading)) +
  geom_bar(stat = "identity", fill = "steelblue", alpha = 0.7) +
  coord_flip() +
  labs(title = "潜变量平均绝对载荷", 
       x = "潜变量", 
       y = "平均绝对载荷") +
  theme_minimal()
print(p4)

# 疾病指标载荷图（专门查看a,b,c,d的载荷）
disease_loadings <- outer_model %>% 
  filter(block == "DiseaseLevel")

if(nrow(disease_loadings) > 0) {
  p5 <- ggplot(disease_loadings, aes(x = reorder(name, loading), y = loading, 
                                     fill = loading > 0)) +
    geom_bar(stat = "identity") +
    coord_flip() +
    scale_fill_manual(values = c("TRUE" = "darkgreen", "FALSE" = "red")) +
    labs(title = "疾病等级指标载荷",
         x = "疾病指标", 
         y = "载荷值") +
    theme_minimal() +
    theme(legend.position = "none")
  print(p5)
}

# ==================== 第八步：模型诊断 ====================

cat("\n========== 模型诊断 ==========\n")

# 1. 信度检验
cat("\n信度指标:\n")
print(pls_result$unidim)

# 2. 检查每个潜变量的AVE（平均方差抽取）
if(!is.null(pls_result$outer_model)) {
  ave_values <- pls_result$outer_model %>%
    group_by(block) %>%
    summarise(AVE = mean(loading^2), .groups = 'drop')
  cat("\n平均方差抽取 (AVE):\n")
  print(ave_values)
}

# 3. 检查疾病等级潜变量的载荷方向一致性
cat("\n疾病等级指标载荷方向检查:\n")
disease_loadings <- outer_model %>% filter(block == "DiseaseLevel")
print(disease_loadings[, c("name", "loading")])

# ==================== 第九步：结果导出 ====================

# 创建路径系数结果
path_names <- rownames(path_coefs)
results_summary <- data.frame()

for(i in 1:length(path_names)) {
  for(j in 1:length(path_names)) {
    if(path_coefs[i,j] != 0 && i != j) {
      results_summary <- rbind(results_summary, data.frame(
        From = path_names[i],
        To = path_names[j],
        Path_Coefficient = path_coefs[i,j]
      ))
    }
  }
}

# 确保总效应数据框不为空
if(nrow(disease_effects_df) == 0) {
  disease_effects_df <- data.frame(
    Factor = character(),
    Total_Effect = numeric()
  )
  cat("\n警告：总效应分析没有生成有效数据\n")
}

# 保存结果到文件
write.csv(results_summary, "PLS-PM_路径系数结果.csv", row.names = FALSE)
write.csv(outer_model, "PLS-PM_外部模型.csv", row.names = FALSE)
write.csv(inner_summary, "PLS-PM_内部模型.csv", row.names = TRUE)
write.csv(disease_effects_df, "PLS-PM_总效应分析.csv", row.names = FALSE)

# 保存潜变量得分
lv_scores_df <- as.data.frame(pls_result$scores)
lv_scores_df$disease_state <- ifelse(df$a == 1, "健康",
                                     ifelse(df$b == 1, "等级1",
                                            ifelse(df$c == 1, "等级2", 
                                                   ifelse(df$d == 1, "等级3", "未知"))))
write.csv(lv_scores_df, "PLS-PM_潜变量得分.csv", row.names = TRUE)

cat("\n========== 分析完成！结果已保存到CSV文件 ==========\n")

# ==================== 第十步：关键发现总结 ====================

cat("\n========== 关键发现总结 ==========\n")

# 高载荷的变量
high_loadings <- outer_model[abs(outer_model$loading) > 0.7, ]
cat("\n高载荷变量 (|loading| > 0.7):\n")
if(nrow(high_loadings) > 0) {
  print(high_loadings[, c("name", "block", "loading")])
} else {
  cat("没有高载荷变量\n")
}

# 疾病等级的解释度
disease_r2 <- inner_summary["DiseaseLevel", "R2"]
cat(sprintf("\n模型对疾病等级变异的解释度 (R²): %.3f\n", disease_r2))

# 最重要的预测因素（考虑总效应）
cat("\n对疾病等级影响最大的因素（总效应）:\n")
if(nrow(disease_effects_df) > 0) {
  print(disease_effects_df)
} else {
  cat("没有计算到有效的总效应\n")
}

# 疾病指标载荷分析
cat("\n疾病等级指标载荷分析:\n")
disease_loadings <- outer_model %>% filter(block == "DiseaseLevel")
print(disease_loadings[, c("name", "loading", "weight")])

# 模型建议
cat("\n========== 模型建议 ==========\n")
cat("1. 模型拟合优度 (GoF):", round(pls_result$gof, 3), "\n")
cat("2. 疾病等级解释度:", round(disease_r2, 3), "\n")

if(nrow(disease_effects_df) > 0) {
  cat("3. 主要影响因素（总效应）:", paste(head(disease_effects_df$Factor, 3), collapse = ", "), "\n")
}

# 各潜变量的关键变量
cat("\n4. 各潜变量的关键变量:\n")
for(block_name in unique(outer_model$block)) {
  block_vars <- outer_model[outer_model$block == block_name, ]
  if(nrow(block_vars) > 0) {
    top_var <- block_vars[which.max(abs(block_vars$loading)), ]
    cat(sprintf("   %s: %s (载荷: %.3f)\n", 
                block_name, top_var$name, top_var$loading))
  }
}

# 生物学解释
cat("\n5. 生物学解释:\n")
cat("   - 土壤理化性质是系统的起点，影响微生物群落和酶活性\n")
cat("   - 微生物和酶活性相互作用，影响代谢物产生\n")
cat("   - 代谢物和植物酶活性直接影响植物健康状况\n")
cat("   - 所有因素（土壤理化、微生物、酶活性、代谢物、植物酶活）都可能直接影响疾病发生\n")
cat("   - 疾病等级由a,b,c,d四个指标共同反映，提供了更丰富的疾病状态信息\n")

