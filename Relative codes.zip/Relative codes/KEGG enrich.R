# 加载必要的包
library(dplyr)
library(ggplot2)
library(stringr)

# 读取数据
data <- read.delim("SCPFCKtonglu.txt", header = FALSE, stringsAsFactors = FALSE)
colnames(data) <- c("Pathway", "KEGG_ID", "Input_number", "Background_number", "Compounds")

# 首先提取所有唯一的化合物来计算有KEGG注释的代谢物总数
all_compounds <- unlist(str_extract_all(data$Compounds, "(?<=\\()[^)]+(?=\\))"))
total_annotated_metabolites <- length(unique(all_compounds))

# 估计总背景代谢物数（KEGG数据库中所有代谢物的估计数）
total_background <- 545  # 你可以根据实际情况调整这个值

# 计算每个通路的富集分析
enrichment_data <- data %>%
  mutate(
    Input_number = as.numeric(Input_number),
    Background_number = as.numeric(Background_number),
    # 计算富集因子
    Enrichment_factor = Input_number / Background_number,
    # 使用超几何检验计算p值
    P_value = phyper(Input_number - 1, 
                     Background_number, 
                     total_background - Background_number, 
                     total_annotated_metabolites, 
                     lower.tail = FALSE),
    # 使用原始p值，不调整
    # -log10转换原始p值
    Log_pvalue = -log10(P_value)
  ) %>%
  # 过滤：去除富集因子等于1的通路
  filter(Enrichment_factor != 1) %>%
  # 过滤：只保留富集因子大于0.4的通路
  filter(Enrichment_factor > 0.2)

# 查看最重要的通路
significant_pathways <- enrichment_data %>%
  filter(P_value < 0.05) %>%
  arrange(P_value)

# 输出统计信息
cat("代谢通路富集分析统计:\n")
cat("总检测到的有KEGG注释的代谢物:", total_annotated_metabolites, "\n")
cat("设定的KEGG总背景代谢物数:", total_background, "\n")
cat("显著富集的通路数 (p < 0.05):", nrow(significant_pathways), "\n")
cat("总分析通路数:", nrow(enrichment_data), "\n\n")

# 显示前10个最显著的通路
if(nrow(significant_pathways) > 0) {
  cat("Top 10 最显著富集的通路:\n")
  for (i in 1:min(10, nrow(significant_pathways))) {
    cat(i, ". ", significant_pathways$Pathway[i], 
        "\n   富集因子: ", round(significant_pathways$Enrichment_factor[i], 3),
        ", p值: ", formatC(significant_pathways$P_value[i], format = "e", digits = 2),
        "\n   输入代谢物: ", significant_pathways$Input_number[i], 
        "/", significant_pathways$Background_number[i], "\n\n", sep = "")
  }
} else {
  cat("没有发现显著富集的通路 (p < 0.05)\n")
}

# 自定义主题 - 绘图区域浅灰色背景，白色网格线，整个图表有边框
custom_theme <- theme_minimal() +
  theme(
    plot.background = element_rect(fill = "white", color = "black", size = 1),  # 整个图表白色背景，黑色边框
    panel.background = element_rect(fill = "grey95", color = NA),  # 绘图区域浅灰色背景
    panel.grid.major = element_line(color = "white", size = 0.5),  # 白色主网格线
    panel.grid.minor = element_line(color = "white", size = 0.25), # 白色次网格线
    plot.title = element_text(hjust = 1, face = "bold"),
    panel.border = element_rect(color = "black", fill = NA, size = 0.5),  # 绘图区域边框
    # 调整坐标轴，确保刻度线延伸到绘图区域外
    axis.ticks = element_line(color = "black", size = 0.5),
    axis.ticks.length = unit(0.15, "cm")
  )

# 可视化1: 富集因子 vs -log10(p值) 散点图 - 使用蓝绿黄红渐变
p1 <- ggplot(enrichment_data, aes(x = Enrichment_factor, y = Log_pvalue)) +
  geom_point(aes(size = Input_number, color = Log_pvalue), alpha = 0.7) +
  scale_color_gradientn(colors = c("blue", "green", "yellow", "red"), 
                        name = "-log10(p值)") +
  scale_size_continuous(name = "代谢物数量", range = c(2, 8)) +  # 限制气泡大小范围
  # 扩展坐标轴刻度，为气泡留出空间
  scale_x_continuous(expand = expansion(mult = c(0.05, 0.1))) +
  scale_y_continuous(expand = expansion(mult = c(0.05, 0.1))) +
  labs(title = "代谢通路富集分析",
       subtitle = paste("总注释代谢物:", total_annotated_metabolites),
       x = "富集因子",
       y = "-log10(p值)") +
  custom_theme

print(p1)

# 可视化2: 前30个最显著通路的条形图 - 使用蓝绿黄红渐变
top_pathways <- enrichment_data %>%
  arrange(P_value) %>%
  head(30)

p2 <- ggplot(top_pathways, aes(x = reorder(Pathway, -P_value), 
                               y = Enrichment_factor)) +
  geom_bar(aes(fill = Log_pvalue), stat = "identity") +
  scale_fill_gradientn(colors = c("blue", "green", "yellow", "red"), 
                       name = "-log10(p值)") +
  # 扩展坐标轴刻度，为条形图留出空间
  scale_y_continuous(expand = expansion(mult = c(0, 0.1))) +
  coord_flip() +
  labs(title = "Top 30 富集代谢通路",
       x = "通路",
       y = "富集因子") +
  custom_theme +
  theme(
    axis.text.y = element_text(size = 8),
    plot.margin = margin(1, 1, 1, 2, "cm")  # 增加边距以适应长通路名称
  )

print(p2)

# 可视化3: 气泡图显示富集程度 - 前30个通路 - 使用蓝绿黄红渐变
top_pathways_bubble <- enrichment_data %>%
  arrange(P_value) %>%
  head(30)

p3 <- ggplot(top_pathways_bubble, aes(x = Enrichment_factor, y = reorder(Pathway, Enrichment_factor))) +
  geom_point(aes(size = Input_number, color = Log_pvalue), alpha = 0.7) +
  scale_color_gradientn(colors = c("blue", "green", "yellow", "red"), 
                        name = "-log10(p值)") +
  scale_size_continuous(name = "代谢物数量", range = c(3, 10)) +  # 限制气泡大小范围
  # 扩展x轴刻度，为气泡留出空间
  scale_x_continuous(expand = expansion(mult = c(0.05, 0.15))) +
  labs(title = "Top 30 代谢通路富集气泡图",
       x = "富集因子",
       y = "通路") +
  custom_theme +
  theme(
    axis.text.y = element_text(size = 7),
    plot.margin = margin(1, 1, 1, 2, "cm")  # 增加边距以适应长通路名称
  )

print(p3)

# 保存结果 - 调整图片尺寸，增加高度，减少宽度
write.csv(enrichment_data, "metabolic_pathway_enrichment_results.csv", row.names = FALSE)

if(nrow(significant_pathways) > 0) {
  write.csv(significant_pathways, "significant_metabolic_pathways.csv", row.names = FALSE)
}

# 创建化合物-通路映射
compound_pathway_map <- data.frame()
for (i in 1:nrow(enrichment_data)) {
  compounds <- unlist(str_extract_all(data$Compounds[i], "(?<=\\()[^)]+(?=\\))"))
  for (compound in compounds) {
    compound_pathway_map <- rbind(compound_pathway_map, 
                                  data.frame(Compound = compound,
                                             Pathway = enrichment_data$Pathway[i],
                                             KEGG_ID = enrichment_data$KEGG_ID[i]))
  }
}

# 查看最常出现的化合物
compound_frequency <- compound_pathway_map %>%
  group_by(Compound) %>%
  summarise(Frequency = n()) %>%
  arrange(desc(Frequency))

cat("\n最常出现的化合物:\n")
print(head(compound_frequency, 10))

write.csv(compound_frequency, "compound_frequency.csv", row.names = FALSE)

