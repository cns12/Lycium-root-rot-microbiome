# =============================================
# 增强版RDA分析代码 - 包含结果导出功能
# =============================================

# 1. 加载必要的包
library(vegan)
library(ggplot2)
library(ggrepel)

# 2. 完全重置图形环境
graphics.off()

# 3. 设置默认图形设备（如果需要）
if (interactive()) {
  dev.new(width = 14, height = 14)
}

# 4. 读取数据
genus_file <- "genus_data.txt"
environment_file <- "environment_data.txt"

genus_data <- read.delim(genus_file, header = TRUE, row.names = 1, check.names = FALSE)
environment_data <- read.delim(environment_file, header = TRUE, row.names = 1, check.names = FALSE)

# 5. 数据预处理
common_samples <- intersect(rownames(genus_data), rownames(environment_data))
genus_data <- genus_data[common_samples, ]
environment_data <- environment_data[common_samples, ]

genus_hell <- decostand(genus_data, "hellinger")

env_numeric <- environment_data[, sapply(environment_data, is.numeric), drop = FALSE]
env_factors <- environment_data[, sapply(environment_data, is.factor) | 
                                  sapply(environment_data, is.character), drop = FALSE]

# 6. RDA分析
if(ncol(env_numeric) > 0) {
  env_numeric_std <- decostand(env_numeric, "standardize")
  rda_result <- rda(genus_hell ~ ., data = env_numeric_std)
} else {
  rda_result <- rda(genus_hell)
}

# 提取轴解释的方差百分比
rda_summary <- summary(rda_result)
rda1_percent <- round(100 * rda_summary$cont$importance[2, 1], 1)
rda2_percent <- round(100 * rda_summary$cont$importance[2, 2], 1)

# 7. 统计检验
# 整体模型显著性
model_sig <- anova(rda_result, permutations = 999)
# 每个环境因子的显著性
env_sig <- anova(rda_result, by = "margin", permutations = 999)

# 8. 提取关键结果用于报告
# 环境因子得分（箭头坐标）
env_scores <- scores(rda_result, display = "bp")
# 物种得分
species_scores <- scores(rda_result, display = "species")
# 样本得分
site_scores <- scores(rda_result, display = "sites")

# 9. 生成解释报告
generate_rda_report <- function(rda_result, env_scores, model_sig, env_sig, rda1_percent, rda2_percent) {
  
  # 创建报告内容
  report <- c(
    "RDA分析结果报告",
    "======================",
    "",
    paste("分析时间:", Sys.time()),
    "",
    "1. 模型整体信息",
    paste("   - RDA1解释方差:", rda1_percent, "%"),
    paste("   - RDA2解释方差:", rda2_percent, "%"),
    paste("   - 累计解释方差 (RDA1+RDA2):", round(rda1_percent + rda2_percent, 1), "%"),
    paste("   - 模型显著性 (p-value):", model_sig$`Pr(>F)`[1]),
    "",
    "2. 环境因子重要性排序",
    "   (按对微生物群落变异的解释力从高到低)"
  )
  
  # 计算环境因子的解释力（箭头长度）
  env_importance <- sqrt(env_scores[,1]^2 + env_scores[,2]^2)
  env_importance <- sort(env_importance, decreasing = TRUE)
  
  for(i in 1:length(env_importance)) {
    env_name <- names(env_importance)[i]
    p_value <- env_sig$`Pr(>F)`[which(rownames(env_sig) == env_name)]
    report <- c(report, 
                paste("   ", i, ".", env_name, 
                      ": 影响强度 =", round(env_importance[i], 3),
                      ", p-value =", round(p_value, 4)))
  }
  
  report <- c(report,
              "",
              "3. 环境因子之间的关系",
              "   (基于箭头夹角判断)"
  )
  
  # 分析环境因子间的关系
  if(nrow(env_scores) > 1) {
    for(i in 1:(nrow(env_scores)-1)) {
      for(j in (i+1):nrow(env_scores)) {
        env1 <- rownames(env_scores)[i]
        env2 <- rownames(env_scores)[j]
        
        # 计算夹角余弦值
        cos_angle <- sum(env_scores[i,] * env_scores[j,]) / 
          (sqrt(sum(env_scores[i,]^2)) * sqrt(sum(env_scores[j,]^2)))
        
        relation <- ifelse(cos_angle > 0.7, "强正相关",
                           ifelse(cos_angle > 0.3, "正相关",
                                  ifelse(cos_angle > -0.3, "弱相关或无相关",
                                         ifelse(cos_angle > -0.7, "负相关", "强负相关"))))
        
        report <- c(report, 
                    paste("   -", env1, "与", env2, ":", relation, 
                          "(夹角余弦值 =", round(cos_angle, 3), ")"))
      }
    }
  }
  
  report <- c(report,
              "",
              "4. 主要结论",
              paste("   - 最重要的环境驱动因子:", names(env_importance)[1]),
              paste("   - 模型解释力:", round(rda1_percent + rda2_percent, 1), "%"),
              paste("   - 统计显著性:", ifelse(model_sig$`Pr(>F)`[1] < 0.05, "显著", "不显著")),
              "",
              "5. 解读指南",
              "   - 箭头长度表示环境因子的影响力",
              "   - 箭头方向表示环境梯度增加的方向", 
              "   - 样本点距离反映群落相似性",
              "   - 环境因子夹角反映它们之间的相关性"
  )
  
  return(report)
}

# 10. 生成并保存报告
rda_report <- generate_rda_report(rda_result, env_scores, model_sig, env_sig, rda1_percent, rda2_percent)

# 保存报告到文件
writeLines(rda_report, "RDA_analysis_report.txt")
cat("RDA分析报告已保存为 RDA_analysis_report.txt\n")

# 11. 保存详细数据结果
# 保存环境因子得分
write.csv(env_scores, "RDA_environment_scores.csv")
cat("环境因子得分已保存为 RDA_environment_scores.csv\n")

# 保存物种得分（前100个最重要的物种）
species_importance <- sqrt(rowSums(species_scores^2))
top_species <- order(species_importance, decreasing = TRUE)[1:min(100, nrow(species_scores))]
write.csv(species_scores[top_species, ], "RDA_species_scores_top100.csv")
cat("重要物种得分已保存为 RDA_species_scores_top100.csv\n")

# 保存样本得分
write.csv(site_scores, "RDA_sample_scores.csv")
cat("样本得分已保存为 RDA_sample_scores.csv\n")

# 12. 保存统计检验结果
sink("RDA_statistical_tests.txt")
cat("RDA统计检验结果\n")
cat("====================\n\n")
cat("1. 整体模型显著性检验:\n")
print(model_sig)
cat("\n2. 各环境因子显著性检验:\n")
print(env_sig)
sink()
cat("统计检验结果已保存为 RDA_statistical_tests.txt\n")

# 13. 创建图形（原有代码保持不变）
tryCatch({
  # 提取坐标数据
  site_scores <- as.data.frame(scores(rda_result, display = "sites"))
  species_scores <- as.data.frame(scores(rda_result, display = "species"))
  
  # 只保留前5个最重要的属
  species_lengths <- sqrt(rowSums(species_scores^2))
  top_species <- order(species_lengths, decreasing = TRUE)[1:min(5, length(species_lengths))]
  species_scores_top <- species_scores[top_species, ]
  species_scores_top$Genus <- rownames(species_scores_top)
  
  # 添加分组信息
  site_scores$Sample <- rownames(site_scores)
  if(ncol(env_factors) > 0) {
    site_scores$Group <- env_factors[site_scores$Sample, 1]
  } else {
    site_scores$Group <- "All Samples"
  }
  
  # 创建ggplot图形
  p <- ggplot() +
    geom_point(data = site_scores, 
               aes(x = RDA1, y = RDA2, color = Group), 
               size = 3, alpha = 0.7) +
    geom_segment(data = species_scores_top,
                 aes(x = 0, y = 0, xend = RDA1, yend = RDA2),
                 arrow = arrow(length = unit(0.15, "cm")),
                 color = "#1f77b4", alpha = 0.7) +
    ggrepel::geom_text_repel(data = species_scores_top,
                             aes(x = RDA1, y = RDA2, label = Genus),
                             color = "#1f77b4", size = 4,
                             box.padding = 0.5, point.padding = 0.5,
                             max.overlaps = 20) +
    {
      if(ncol(env_numeric) > 0) {
        env_scores <- as.data.frame(scores(rda_result, display = "bp"))
        env_scores$Variable <- rownames(env_scores)
        
        mul_factor <- 0.8 * max(abs(site_scores[, c("RDA1", "RDA2")])) / 
          max(sqrt(env_scores$RDA1^2 + env_scores$RDA2^2))
        
        env_scores$RDA1_scaled <- env_scores$RDA1 * mul_factor
        env_scores$RDA2_scaled <- env_scores$RDA2 * mul_factor
        
        list(
          geom_segment(data = env_scores,
                       aes(x = 0, y = 0, xend = RDA1_scaled, yend = RDA2_scaled),
                       arrow = arrow(length = unit(0.2, "cm")),
                       color = "#d62728", linewidth = 0.8),
          ggrepel::geom_text_repel(data = env_scores,
                                   aes(x = RDA1_scaled, y = RDA2_scaled, label = Variable),
                                   color = "#d62728", size = 4, fontface = "bold")
        )
      }
    } +
    geom_hline(yintercept = 0, linetype = "dashed", alpha = 0.5) +
    geom_vline(xintercept = 0, linetype = "dashed", alpha = 0.5) +
    labs(x = paste0("RDA1 (", rda1_percent, "%)"),
         y = paste0("RDA2 (", rda2_percent, "%)"),
         title = "RDA双序图 - 属水平") +
    theme_bw() +
    theme(panel.grid = element_blank(),
          plot.title = element_text(hjust = 0.5)) +
    coord_fixed(ratio = 1)
  
  print(p)
  ggsave("RDA_ggplot_biplot.png", p, width = 14, height = 14, dpi = 300)
  cat("ggplot2图形已保存为 RDA_ggplot_biplot.png\n")
  
}, error = function(e) {
  cat("ggplot2图形创建失败:", e$message, "\n")
})

# 14. 最终总结
cat("\n=== RDA分析完成 ===\n")
cat("生成的文件:\n")
cat("1. RDA_analysis_report.txt - 分析报告\n")
cat("2. RDA_environment_scores.csv - 环境因子坐标\n")
cat("3. RDA_species_scores_top100.csv - 重要物种坐标\n")
cat("4. RDA_sample_scores.csv - 样本坐标\n")
cat("5. RDA_statistical_tests.txt - 统计检验结果\n")
cat("6. RDA_ggplot_biplot.png - RDA图形\n")

