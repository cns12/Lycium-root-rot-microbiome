library(NST)
library(picante)
library(ape)

#读取 OTU 丰度表
otu <- read.csv('枸杞细菌群落.csv', row.names = 1)
otu <- data.frame(t(otu))

#读取样本分组文件
group <- read.csv('treat.csv', row.names = 1)

#读取 OTU 的进化树文件
tree <- read.tree('tree.nwk')

#修剪系统发育树以仅包含群落数据集中存在的物种或具有非缺失性状数据的物种
tree <- prune.sample(otu, tree)

#函数 pNST() 本是用来计算 pNST 指数的，通过添加参数 SES=TRUE 即可同时计算 betaMNTD 和 betaNTI，详情 ?pNST
#phylo.shuffle=TRUE 意为在系统发育树中随机置换以随机化物种之间的系统发育关系
#taxo.null.model，随机化丰度矩阵的零模型算法，默认为 NULL 意为只进行系统发育洗牌。若有需要指定具体的零模型，请更改此处
#rand 指定获得 betaMNTD 零分布的置换次数，本示例以 1000 次随机为例
#nworker 指定多线程，本示例 4 线程运行
#此外，pNST() 还可通过参数 RC=TRUE 计算 Raup-Crick（不知此时是否需要修改 taxo.null.model？），但是本示例没有再执行它，细节部分还请参阅函数帮助
set.seed(123)
pnst <- pNST(comm = otu, tree = tree, group = group, phylo.shuffle = TRUE, taxo.null.model = NULL, 
             pd.wd = tempdir(), abundance.weighted = TRUE, rand = 500, nworker = 10, SES = TRUE, RC = FALSE)

#本篇主要是计算 betaMNTD 和 betaNTI，暂且不管其它的（比方说 pNST），因此在结果项里面，主要看这个就行了
#names(pnst)
betaMNTD <- pnst$index.pair
head(betaMNTD)

#输出两两样本的 betaMNTD 和 betaNTI
write.csv(betaMNTD, 'betaMNTD.csv', quote = FALSE, row.names= FALSE)

