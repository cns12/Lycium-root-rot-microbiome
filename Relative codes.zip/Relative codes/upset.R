# =============================================================================
# 根际代谢差异物UpSet分析与结果导出
# 输入文件：根际代谢差异物韦恩.txt（制表符分隔，每列为一个比较组的差异物列表）
# 输出文件：
#   1. upset_plot.pdf         - UpSet图
#   2. upset_data.csv         - 二进制矩阵（代谢物在各组出现情况）
#   3. intersection_counts.csv- 各交集组合的代谢物数量
#   4. unique_metabolites.csv - 每组独有的代谢物列表
# =============================================================================

# 加载必要的包
library(UpSetR)
library(tidyverse)

# 1. 读取数据（制表符分隔，填充空白单元格为NA）
data <- read.table("根际代谢差异物韦恩.txt", 
                   header = TRUE, 
                   sep = "\t", 
                   fill = TRUE, 
                   stringsAsFactors = FALSE)

# 获取所有比较组名称
groups <- colnames(data)

# 2. 构建二进制矩阵（代谢物 × 组）
# 提取所有代谢物的并集（去除NA和空字符串）
all_metabolites <- data %>%
  pivot_longer(everything(), names_to = "group", values_to = "metabolite") %>%
  filter(!is.na(metabolite) & metabolite != "") %>%
  pull(metabolite) %>%
  unique()

# 创建二进制数据框
upset_df <- data.frame(metabolite = all_metabolites)

for (g in groups) {
  # 当前组的代谢物列表（去除NA）
  group_met <- data[[g]][!is.na(data[[g]]) & data[[g]] != ""]
  upset_df[[g]] <- ifelse(upset_df$metabolite %in% group_met, 1, 0)
}

# 将代谢物设为行名
rownames(upset_df) <- upset_df$metabolite
upset_mat <- upset_df[, -1, drop = FALSE]  # 仅保留二进制列

# 3. 导出二进制矩阵
write.csv(upset_mat, "upset_data.csv", row.names = TRUE)

# 4. 计算各组独有的代谢物
unique_list <- list()
for (g in groups) {
  # 在该组为1，且在其他所有组均为0的代谢物
  other_cols <- setdiff(groups, g)
  unique_met <- upset_mat[upset_mat[[g]] == 1 & 
                            rowSums(upset_mat[, other_cols, drop = FALSE]) == 0, ]
  unique_list[[g]] <- rownames(unique_met)
}

# 将独有代谢物导出为CSV（长格式）
unique_df <- stack(unique_list)
names(unique_df) <- c("metabolite", "group")
write.csv(unique_df, "unique_metabolites.csv", row.names = FALSE)

# 5. 计算所有可能的交集大小
# 使用UpSetR内置函数，或手动计算
# 方法：将二进制矩阵转换为列表，然后计算组合
library(ComplexHeatmap)  # 提供make_comb_mat函数
if (!require(ComplexHeatmap)) BiocManager::install("ComplexHeatmap")
library(ComplexHeatmap)

# 将二进制矩阵转为逻辑矩阵
m <- as.matrix(upset_mat) == 1

# 生成组合矩阵
comb_mat <- make_comb_mat(m)

# 提取交集大小
intersection_size <- comb_size(comb_mat)
intersection_df <- data.frame(
  combination = names(intersection_size),
  size = as.vector(intersection_size)
)

# 添加各组的成员信息（可选，方便阅读）
# 解析组合名称，例如 "1110000" 表示前三个组有，后四个无
# 这里不展开，保留原始组合名称即可

write.csv(intersection_df, "intersection_counts.csv", row.names = FALSE)

# 6. 绘制UpSet图并保存
# 注释掉保存部分
# pdf("upset_plot.pdf", width = 12, height = 8)
upset(upset_mat,
      sets = groups,
      keep.order = TRUE,
      order.by = "freq",
      sets.bar.color = "#56B4E9",
      mainbar.y.label = "交集代谢物数量",
      sets.x.label = "比较组大小",
      mb.ratio = c(0.6, 0.4),
      text.scale = c(1.3, 1.3, 1, 1, 1.5, 1))
# dev.off()

cat("分析完成！生成的文件：\n")
cat("  - upset_plot.pdf\n")
cat("  - upset_data.csv\n")
cat("  - unique_metabolites.csv\n")
cat("  - intersection_counts.csv\n")

